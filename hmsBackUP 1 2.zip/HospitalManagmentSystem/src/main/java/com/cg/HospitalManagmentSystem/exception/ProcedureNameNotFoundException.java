package com.cg.HospitalManagmentSystem.exception;

public class ProcedureNameNotFoundException extends RuntimeException
{

	public ProcedureNameNotFoundException(String msg)
	{
		super(msg);
	}
}
