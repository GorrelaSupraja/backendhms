package com.cg.HospitalManagmentSystem.serviceImpl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.HospitalManagmentSystem.exception.AlreadyFoundException;
import com.cg.HospitalManagmentSystem.exception.ExaminationRoomNotFoundException;
import com.cg.HospitalManagmentSystem.exception.FieldsNotFoundException;
import com.cg.HospitalManagmentSystem.exception.NoAppointmentFoundForId;
import com.cg.HospitalManagmentSystem.exception.NoAppointmentFoundForPhysicianId;
import com.cg.HospitalManagmentSystem.exception.NoNurseFoundByPatientIdException;
import com.cg.HospitalManagmentSystem.exception.NurseNotFoundException;
import com.cg.HospitalManagmentSystem.exception.PatientNotFoundException;
import com.cg.HospitalManagmentSystem.exception.RoomNotFoundException;
import com.cg.HospitalManagmentSystem.model.Appointment;
import com.cg.HospitalManagmentSystem.model.Nurse;
import com.cg.HospitalManagmentSystem.model.Patient;
import com.cg.HospitalManagmentSystem.model.Physician;
import com.cg.HospitalManagmentSystem.model.Room;
import com.cg.HospitalManagmentSystem.repository.AppointmentRepository;
import com.cg.HospitalManagmentSystem.repository.NurseRepository;
import com.cg.HospitalManagmentSystem.repository.PatientRepository;
import com.cg.HospitalManagmentSystem.repository.PhysicianRepository;
import com.cg.HospitalManagmentSystem.repository.RoomRepository;
import com.cg.HospitalManagmentSystem.service.HMSAppointmentService;

@Service
public class HMSAppointmentServiceImpl implements HMSAppointmentService{
	
	@Autowired AppointmentRepository appRepo;
	@Autowired PatientRepository patRepo;
	@Autowired PhysicianRepository phyRepo;
	@Autowired RoomRepository roomRepo;
	@Autowired NurseRepository nurserepo;
	
	@Override
	public Appointment updateExaminationRoom(Integer appointmentid, String newExaminationRoom) {
		Appointment a = appRepo.findById(appointmentid).orElse(null);
		a.setExaminationRoom(newExaminationRoom);
		return appRepo.save(a);
	}

	@Override
	public HashSet<Patient> getPatientCheckedByPhysician(int physicianid) {
		HashSet<Patient> patSet = new HashSet<>();
		List<Appointment> applist = appRepo.findByPhysician(physicianid);
		if (applist.isEmpty()) throw new NoAppointmentFoundForPhysicianId("No Appointment Found For PhysicianId " + physicianid);
		for (Appointment a : applist) {
			Patient p = a.getPatient();
			int ssn = p.getSsn();
			patSet.add(patRepo.findById(ssn).get());
		}
		return patSet;
	}

	
	

	@Override
	public Patient getPatientByPatientIdAndPhysicianId(int physicianid, int patientid) {
		for (Appointment a : appRepo.findByPhysician(physicianid)) {
			if (a.getPatient().getSsn() == patientid) {
				return a.getPatient();
			}
		}
		return null;
	}

	@Override
	public Patient getPatientByAppointment(int appointmentid) {
		Appointment a = appRepo.findById(appointmentid).orElse(null);
		if (a == null) throw new NoAppointmentFoundForId(appointmentid + " Not Found!");
		Integer ssn =  a.getPatient().getSsn();
		return patRepo.findById(ssn).orElse(null);
	}

	@Override
	public Physician getPhysicianByAppointment(int appointmentid) {
		Integer empId = appRepo.findById(appointmentid).orElse(null).getPhysician().getEmployeeID();
		return phyRepo.findById(empId).orElse(null);
	}

	@Override
	public List<Room> getRoomByPhysicianIdOnDate(int physicianid, LocalDateTime date) {
		return roomRepo.getRoomByPhyIdOnDate(physicianid, date);
	}
	@Override
	public List<Appointment> getAllAppointments()

	{

		return appRepo.findAll();	

	}

	@Override
	public List<Appointment> getAppointmentsByStartDate(LocalDateTime startDate)

	{

		return appRepo.findByStart(startDate);

	}
	@Override
	public List<Physician> getPhysicianByPatientIdAndDate(String patientId, LocalDateTime date) {

        List<Appointment> appointments = appRepo.findByPatientIdAndDate(patientId, date);

        return appointments.stream()

            .map(Appointment::getPhysician)

            .filter(physician -> physician != null) // Handle null physicians

            .distinct()

            .collect(Collectors.toList());

    }

	@Override
    public List<Nurse> getNursesByPatientIdAndDate(String patientId, LocalDateTime date) {

        return appRepo.findNursesByPatientIdAndDate(patientId, date);

    }

	@Override
    public List<LocalDateTime> getAppointmentDatesByPatientId(int patientId) {

        List<Appointment> appointments = appRepo.findByPatientSsn(patientId);

        return appointments.stream()

                           .map(Appointment::getStart)

                           .collect(Collectors.toList());

    }
	
	@Override
    public String getExaminationRoomByPatientIdAndDate(int patientId, LocalDate date) {

        LocalDateTime startOfDay = date.atStartOfDay();

        LocalDateTime endOfDay = date.atTime(LocalTime.MAX);

        Optional<Appointment> appointment = appRepo.findByPatientSsnAndStartBetween(patientId, startOfDay, endOfDay);

        return appointment.map(Appointment::getExaminationRoom).orElse("No appointment found for the given date.");

    }
	
	@Override
    public Nurse getNurseByPatientIdAndDate(int patientId, LocalDateTime dateTime) {

        return appRepo.findByPatientSsnAndStart(patientId, dateTime)

                                    .map(Appointment::getPrepNurse)

                                    .orElse(null);

    }
	
	@Override
    public List<Nurse> getNursesByPatientId(int patientId) {

        List<Nurse> nurse = appRepo.findNursesByPatientId(patientId);

        if (nurse.isEmpty()) throw new NoNurseFoundByPatientIdException(patientId+" Nurse not found for this patient id");

        return nurse;

    }
	@Override
    public Nurse getNurseByAppointmentId(Integer appointmentId) {
         Nurse n=nurserepo.getNurseByappId(appointmentId);
         if(n== null) {
        	 throw new NurseNotFoundException("Nurse  not found");
         }
        return nurserepo.getNurseByappId(appointmentId);

	}
	@Override
	public String getExamintionRoomByappId(int id) {

		String s=appRepo.getExaminationRoomBYappID(id);

		if(s==null) {

			throw new ExaminationRoomNotFoundException("No examinationroom found for this id: "+ id );

		}

		return appRepo.getExaminationRoomBYappID(id);

	}
	
	@Override
	public HashSet<Patient> getPateientsByNusreId(int nurseid){
		List<Appointment> appList=appRepo.findByPrepNurse(nurseid);
		HashSet<Patient> patientList = new HashSet<>();
		for(Appointment app:appList)
		{
			patientList.add(app.getPatient());
		}
		
		if(patientList.isEmpty()) throw new PatientNotFoundException("Patients not found");
		return patientList;


	} 

	@Override
	public Patient getPatientByPatientIdAndNurseId(int nurseid, int patientid) {

		for (Appointment a : appRepo.findByPrepNurse(nurseid)) {

			if (a.getPatient().getSsn() == patientid) {

				return a.getPatient();

			}

		}

	 throw new PatientNotFoundException("Patient with ID " + patientid + " not found for nurse with ID " + nurseid);

	}
	
	@Override
	public void postApp(Appointment a) {
		int id =a.getAppointmentID() ;
		if(appRepo.existsById(id)) {
			throw new AlreadyFoundException("Appointment already  found By this Id");
		}
		if(a.getPhysician()==null || a.getPatient()==null || a.getPrepNurse()==null) {
			throw new FieldsNotFoundException("*All details have to  assign properly ??");
		}
		appRepo.save(a);

	}

 
	
	@Override
public HashSet<Patient> getPatientsBynurseandDate(int nurseid,LocalDate starto){
		
		List<Appointment> appList=appRepo.findByPrepNurse(nurseid);
		HashSet<Patient> patientList = new HashSet<>();
		
		for(Appointment app:appList)
		{   
			LocalDate d = app.getStart().toLocalDate();
			if (starto.equals(d)) {
				Patient p = app.getPatient();
				int ssn = p.getSsn();
				patientList.add(patRepo.findById(ssn).get());
		}}
		if(patientList.isEmpty()) throw new PatientNotFoundException("Patients not found");
		return patientList;
		}
	
	
 
	
	@Override
	public List<Room> getRoomList(int nurseId, LocalDateTime date) {

		List<Room> li =roomRepo.getRoomByNurseIdOnDate(nurseId, date);

		if(li.isEmpty()) {

			throw new RoomNotFoundException("Rooms not found with this details: "+nurseId);

		}


		return roomRepo.getRoomByNurseIdOnDate(nurseId, date);

	}
 
	

	@Override
	public List<Appointment> getAll(){

		return  appRepo.findAll();

		}

	@Override
	public HashSet<Patient> getPatientCheckedByPhysicianOnDate(int physicianid, LocalDate date) {
		HashSet<Patient> patSet = new HashSet<>();
		for (Appointment a : appRepo.findByPhysician(physicianid)) {
			LocalDate d = a.getStart().toLocalDate();
			if (date.equals(d)) {
				Patient p = a.getPatient();
				int ssn = p.getSsn();
				patSet.add(patRepo.findById(ssn).get());
			}
		}
		return patSet;
	}
 
 


}
