package com.cg.HospitalManagmentSystem.model;
 
import java.util.List;
 
import com.fasterxml.jackson.annotation.JsonIgnore;
 
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
 
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Physician")
public class Physician {
	public Physician(Integer employeeID) {
		super();
		this.employeeID = employeeID;
	}

	@Id
	@Column(name="EmployeeID")
    private Integer employeeID;
 
    @Column(nullable = false, length = 30, name = "Name")
    private String name;
 
    @Column(nullable = false, length = 30, name="Position")
    private String position;
 
    @Column(nullable = false, name = "SSN")
    private Integer ssn;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "head")
    @JsonIgnore
    private List<Department> departments;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "physician")
    @JsonIgnore
    private List<Affiliated_With> affiliations;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "pcp")
    @JsonIgnore
    private List<Patient> patients;
    @OneToMany(mappedBy = "physician", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Appointment> appointments;
    @OneToMany(mappedBy = "physician", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Prescribes> prescriptions;
    @OneToMany(mappedBy = "physician")
    @JsonIgnore
    private List<Undergoes> undergoes;
    @OneToMany(mappedBy = "physician")
    @JsonIgnore
    private List<Trained_In> trainedIns;

 
	@Override
	public String toString() {
		return "Physician [employeeID=" + employeeID + ", name=" + name + ", position=" + position + ", ssn=" + ssn
				+ "]";
	}
	public Integer getEmployeeID() {
	    return employeeID;
	}
 
	public void setEmployeeID(Integer employeeID) {
	    this.employeeID = employeeID;
	}
 
	public String getName() {
	    return name;
	}
 
	public void setName(String name) {
	    this.name = name;
	}
 
	public String getPosition() {
	    return position;
	}
 
	public void setPosition(String position) {
	    this.position = position;
	}
 
	public Integer getSsn() {
	    return ssn;
	}
 
	public void setSsn(Integer ssn) {
	    this.ssn = ssn;
	}
 
	public List<Department> getDepartments() {
	    return departments;
	}
 
	public void setDepartments(List<Department> departments) {
	    this.departments = departments;
	}
 
	public List<Affiliated_With> getAffiliations() {
	    return affiliations;
	}
 
	public void setAffiliations(List<Affiliated_With> affiliations) {
	    this.affiliations = affiliations;
	}
 
	public List<Patient> getPatients() {
	    return patients;
	}
 
	public void setPatients(List<Patient> patients) {
	    this.patients = patients;
	}
 
	public List<Appointment> getAppointments() {
	    return appointments;
	}
 
	public void setAppointments(List<Appointment> appointments) {
	    this.appointments = appointments;
	}
 
	public List<Prescribes> getPrescriptions() {
	    return prescriptions;
	}
 
	public void setPrescriptions(List<Prescribes> prescriptions) {
	    this.prescriptions = prescriptions;
	}
 
	public List<Undergoes> getUndergoes() {
	    return undergoes;
	}
 
	public void setUndergoes(List<Undergoes> undergoes) {
	    this.undergoes = undergoes;
	}
 
	public List<Trained_In> getTrainedIns() {
	    return trainedIns;
	}
 
	public void setTrainedIns(List<Trained_In> trainedIns) {
	    this.trainedIns = trainedIns;
	}
 
}