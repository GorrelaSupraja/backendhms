package com.cg.HospitalManagmentSystem.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.HospitalManagmentSystem.model.*;
import com.cg.HospitalManagmentSystem.serviceImpl.HMSDepartmentServiceImpl;

import lombok.AllArgsConstructor;
import lombok.Data;
@CrossOrigin("*")
@RestController
@Transactional
@AllArgsConstructor
@Data
public class HMSDepartmentController {
	@Autowired
	private HMSDepartmentServiceImpl deptService;
	//Add new Department object in DB
	@PostMapping("/api/department")
	 public ResponseEntity<String> createNewDepartment(@RequestBody Department dept)
	 {
		 Department dep=deptService.createDepartment(dept);
		 return new ResponseEntity<String>("Record Created Successfully", HttpStatus.CREATED);
	 }
	 
	//Get the list of department
	@GetMapping("/api/departments/")
	public ResponseEntity<List<Department>> getAllDepartments()
	{
		List<Department> li=deptService.getAllDepartments();
		return new ResponseEntity<List<Department>>(li, HttpStatus.OK);
			
	}
	
	
	//Search the department detail by dept Id
	@RequestMapping(value="/api/department/{deptid}", method=RequestMethod.GET)
	public ResponseEntity<Department> getDepartmentById(@PathVariable("deptid") Integer deptid)
	{
		Department dept=deptService.getDepartmentById(deptid);
		return new ResponseEntity<Department>(dept, HttpStatus.OK);
	}
	
	
	///search the head of department details
	@GetMapping("/api/department/head/{deptid}")
	public ResponseEntity<Physician> getHeadByDeptId(@PathVariable("deptid") Integer deptid)
	{
		Physician p1=deptService.getHeadByDeptId(deptid);
		return new ResponseEntity<Physician>(p1, HttpStatus.OK);
		
	}
	
	//Search the head certification detail by deptid
	@GetMapping("/api/department/headcertification/{deptid}")
	public ResponseEntity<List<Trained_In>> getHeadCertificationsByDeptId(@PathVariable("deptid") Integer departmentId)
	{
		List<Trained_In> trainedList=deptService.findCertificationsByDeptid(departmentId);
		return new ResponseEntity<List<Trained_In>>(trainedList,HttpStatus.OK);
	}
	
	
	//Search the list of department by head id (physician id)
	@GetMapping("api/departmentsByHead/{head}")
	public ResponseEntity<List<Department>> getDepartmentsByHead(@PathVariable("head") Integer head)
	{
		List<Department> departments=deptService.getDepartmentsByHead(head);
		return new ResponseEntity<List<Department>>(departments, HttpStatus.OK);
	}
	
	//Search whether a physician is head of any department or not
	@GetMapping("/api/department/check/{physicianid}")
	public boolean getDeptByPhysicianId(@PathVariable("physicianid") Integer physicianId)
	{
		return deptService.existsByPhysicianId(physicianId);
		
		
	}
	
//	//Update the department head id
//	@PutMapping("/api/department/update/headid/{deptid}")
//	public ResponseEntity<Department> updateHeadByDeptid(@PathVariable("deptid") Integer departmentId,@RequestBody Department updatedDept)
//	{
//		Department existingDept=deptService.updateHeadByDeptId(departmentId);
//		existingDept.setHead(updatedDept.getHead());
//		return new ResponseEntity<Department>(existingDept, HttpStatus.OK);
//		
//	}
	
//	Update the department head id
	@PutMapping("/api/department/update/headid/{deptid}")
	public ResponseEntity<Department> updateHeadByDeptid(@PathVariable("deptid") Integer departmentId,@RequestBody Physician updatedHead)
	{
		Department updatedDept=deptService.updateHeadByDeptId(departmentId,updatedHead);
		return new ResponseEntity<Department>(updatedDept, HttpStatus.OK);
		
	}
	
	//Update the name of department
	@PutMapping("/api/department/update/deptname/{deptid}")
	public ResponseEntity<Department> updateDeptNameByDeptId(@PathVariable("deptid") Integer departmentId, @RequestBody
			Map<String, String> reqBody1)
	{
		String newDepartmentName=reqBody1.get("name");
		Department Dept=deptService.updateDepartmentName(departmentId, newDepartmentName);
		return new ResponseEntity<Department>(Dept, HttpStatus.OK);	
	}
	
	
}
