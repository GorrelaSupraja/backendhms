package com.cg.HospitalManagmentSystem.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.HospitalManagmentSystem.model.Physician;
import com.cg.HospitalManagmentSystem.model.Procedures;
import com.cg.HospitalManagmentSystem.model.Trained_In;
import com.cg.HospitalManagmentSystem.service.HMSTrainedInService;

import lombok.AllArgsConstructor;

@RestController
@Transactional
@AllArgsConstructor
public class HMSTrainedInController {

	 HMSTrainedInService trainedInService;
	 

	 @GetMapping("/api/trained_in/treatment/{physicianId}")
	 public ResponseEntity<List<Procedures>> getTreatmentsByPhysician(@PathVariable("physicianId") Integer physicianID)
	 {
		 List<Procedures> treatments = trainedInService.getTreatmentsByPhysician(physicianID);
		 return new ResponseEntity<List<Procedures>>(treatments,HttpStatus.OK);
	 }
	 
	 
//	 created exception
	 @GetMapping("/api/trained_in/physicians/{procedureid}")
	 public ResponseEntity<List<Physician>> getPhysiciansByTreatment(@PathVariable("procedureid") Integer treatmentCode)
	 {
		 List<Physician> physicians = trainedInService.getPhysicianByTreatment(treatmentCode);
		 return new ResponseEntity<List<Physician>>(physicians,HttpStatus.OK);
	 }
	 
	 
	 @GetMapping("/api/trained_in/")
	 public ResponseEntity<List<Procedures>> getCertifiedProcedures() 
	 {
		 List<Procedures> procedures = trainedInService.getCertifiedProcedures();
		 return new ResponseEntity<List<Procedures>>(procedures,HttpStatus.OK);
	 }
	 
	 
//	 created exception
	 @GetMapping("/api/trained_in/expiredsooncerti/{physicianid}")
	 public ResponseEntity<List<Procedures>> getExpiringCertificates(@PathVariable("physicianid") Integer physicianId)
	 {
		List<Procedures> li=trainedInService.getProceduresWithExpiringCertifications(physicianId);
		return new ResponseEntity<List<Procedures>>(li,HttpStatus.OK); 
	 }
	 
	 
	 @PostMapping("/api/trained_in")
	 public ResponseEntity<String> createTrainedIn(@RequestBody Trained_In trainedIn)
	 {
		 Trained_In savedTrainedIn = trainedInService.saveTrainedIn(trainedIn);
		 return new ResponseEntity<>("Record Created Successfully", HttpStatus.CREATED);
	 }
	 
	 
	 @GetMapping("/api/trained_in/getAll")
	 public ResponseEntity<List<Trained_In>> getAll()
	 {
		 List<Trained_In> tall=trainedInService.findAll();
		 return new ResponseEntity<List<Trained_In>>(tall,HttpStatus.OK);	 
	 }
	 
	 @PutMapping("/api/trained_in/certificationexpiry/{physicianid}/{procedureid}")

		public ResponseEntity<Boolean> updateCertificationExpiry(@PathVariable("physicianid") int physicianid, @PathVariable("procedureid") int procedureid, @RequestBody Map<String, LocalDateTime> reqBody) {

			LocalDateTime newCertificationExpiry = reqBody.get("newCertificationExpiry");

			Boolean res = trainedInService.updateCertificationExpiry(physicianid, procedureid, newCertificationExpiry);

			return new ResponseEntity<Boolean>(res, HttpStatus.OK);

		}

	 
	 
}
