package com.cg.HospitalManagmentSystem.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table (name = "Room")
public class Room {
	 @Id
	 @Column(name = "RoomNumber")
	 private Integer roomNumber;

    @Column(nullable = false, length = 30, name = "RoomType")
    private String roomType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns({
        @JoinColumn(name = "BlockFloor", referencedColumnName = "BlockFloor"),
        @JoinColumn(name = "BlockCode", referencedColumnName = "BlockCode")
    })
    @JsonIgnore
    private Block block;
    
    @OneToMany(mappedBy = "room")
    @JsonIgnore
    private List<Stay> stays;

    @Column(nullable = false, name = "Unavailable")
    private Boolean unavailable;

	@Override
	public String toString() {
		return "Room [roomNumber=" + roomNumber + ", roomType=" + roomType + ", unavailable=" + unavailable + "]";
	}
    
    
}
