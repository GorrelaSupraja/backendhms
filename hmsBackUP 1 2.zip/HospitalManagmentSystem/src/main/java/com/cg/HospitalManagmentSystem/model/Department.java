package com.cg.HospitalManagmentSystem.model;
 
import java.util.List;
 
import com.fasterxml.jackson.annotation.JsonIgnore;
 
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
 
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Department")
public class Department {
	

	@Id
	@Column(name = "DepartmentID")
    private Integer departmentID;
 
    @Column(nullable = false, length = 30, name = "Name")
    private String name;
    
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "Head")
    private Physician head;
    
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "department")
    @JsonIgnore
    private List<Affiliated_With> affiliations;
    
    public Department(Integer departmentID) {
		super();
		this.departmentID = departmentID;
	}
 
	@Override
	public String toString() {
		return "Department [departmentID=" + departmentID + ", name=" + name + "]";
	}
	public Integer getDepartmentID() {
	    return departmentID;
	}
 
	public void setDepartmentID(Integer departmentID) {
	    this.departmentID = departmentID;
	}
 
	public String getName() {
	    return name;
	}
 
	public void setName(String name) {
	    this.name = name;
	}
 
	public Physician getHead() {
	    return head;
	}
 
	public void setHead(Physician head) {
	    this.head = head;
	}
 
	public List<Affiliated_With> getAffiliations() {
	    return affiliations;
	}
 
	public void setAffiliations(List<Affiliated_With> affiliations) {
	    this.affiliations = affiliations;
	}
 
     
}

