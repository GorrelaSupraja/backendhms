package com.cg.HospitalManagmentSystem.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.cg.HospitalManagmentSystem.model.Users;
import com.cg.HospitalManagmentSystem.repository.UserRepository;
import com.cg.HospitalManagmentSystem.security.JwtService;
@Service
public class HMSUserServiceImpl {
	@Autowired
	private UserRepository urepo;
	@Autowired
	private JwtService jwtservice;
	@Autowired
	AuthenticationManager authManager;
	private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);
	public Users register(Users user) {
		user.setPassword(encoder.encode(user.getPassword()));
		return urepo.save(user);
	}
	public String verify(Users users) {
		org.springframework.security.core.Authentication authentication = authManager.authenticate(new UsernamePasswordAuthenticationToken(users.getUsername(),users.getPassword()));
		if(authentication.isAuthenticated()) {
			return jwtservice.generateToken(users.getUsername());
		}
		return "failure";
	}
 
}
