package com.cg.HospitalManagmentSystem.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.HospitalManagmentSystem.model.Appointment;
import com.cg.HospitalManagmentSystem.model.Nurse;
import com.cg.HospitalManagmentSystem.model.Patient;
import com.cg.HospitalManagmentSystem.model.Physician;
import com.cg.HospitalManagmentSystem.model.Room;
import com.cg.HospitalManagmentSystem.service.HMSAppointmentService;

@RestController
@Transactional
public class HMSAppointmentController {
	
	@Autowired HMSAppointmentService appService;
	
	
	private static final DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

	// api/appointment/patient/{physicianid}	GET	Get a list of patient checked by physician	Collection of Patient
	@GetMapping("api/appointment/patient/{physicianid}")
	public ResponseEntity<HashSet<Patient>> getListOfPatientCheckedByPhysician(@PathVariable("physicianid") int physicianid) {
		HashSet<Patient> p = appService.getPatientCheckedByPhysician(physicianid);
		return new ResponseEntity<HashSet<Patient>>(p, HttpStatus.OK);
	}
	
	//api/appointment/patient/{physicianid}/{date}	GET	Get a list of patient checked by physician on particular date	Collection of Patient
	@GetMapping("api/appointment/patient/physicainid/{physicianid}/date/{date}")
	public ResponseEntity<HashSet<Patient>> getListOfPatientCheckedPhysicianOnDate(@PathVariable("physicianid") int physicianid, @PathVariable("date") LocalDate date) {
		HashSet<Patient> p = appService.getPatientCheckedByPhysicianOnDate(physicianid, date);
		return new ResponseEntity<HashSet<Patient>>(p, HttpStatus.OK);
	}
	
	
	
	@GetMapping("api/appointment/physician/{physicianid}/patient/{patientid}")
	public ResponseEntity<Patient> getPatientByPhysicianIdAndAppointmentId(@PathVariable("physicianid") int physicianid, @PathVariable("patientid") int patientid) {
		Patient p = appService.getPatientByPatientIdAndPhysicianId(physicianid, patientid);
		return new ResponseEntity<Patient>(p, HttpStatus.OK);
	}
	
//	//api/appointment/room/{physicianid}/{date}	GET	Get a list of room details by physician id on a particular date	Collection of Room
	@GetMapping("api/appointment/room/{physicianid}/{date}")
	public ResponseEntity<List<Room>> getRoomByPhysicianIdOnDate(@PathVariable("physicianid") int physicianid,@PathVariable("date") LocalDateTime date) {
		List<Room> r = appService.getRoomByPhysicianIdOnDate(physicianid, date);
		return new ResponseEntity<List<Room>>(r, HttpStatus.OK);
	}
	
	@GetMapping("api/appointment/patient/appointmentid/{appointmentid}")
	public ResponseEntity<Patient> getPatientByAppointment(@PathVariable("appointmentid") int appointmentid) {
		Patient p = appService.getPatientByAppointment(appointmentid);
		return new ResponseEntity<Patient>(p, HttpStatus.OK);
	}
	@GetMapping("api/appointment/physician/appointmentid/{appointmentid}")
	public ResponseEntity<Physician> getPhysicianByAppointment(@PathVariable("appointmentid") int appointmentid) {
		Physician p = appService.getPhysicianByAppointment(appointmentid);
		return new ResponseEntity<Physician>(p, HttpStatus.OK);
	}
	
	@GetMapping("/api/appointment")
	public ResponseEntity<List<Appointment>> getAllAppointments()
	{
		List<Appointment> li=appService.getAllAppointments();
		return new ResponseEntity<List<Appointment>>(li,HttpStatus.OK);
	}

	@GetMapping("/api/appointment/{startdate}")
	public ResponseEntity<List<Appointment>> getAppointmentByStartDate(@PathVariable("startdate") String startdate)
	{
		// Parse the startdate string to LocalDateTime
        LocalDateTime startDate;
        try 
        {
            startDate = LocalDateTime.parse(startdate, formatter);
        } 
        catch (Exception e)
        {
            return ResponseEntity.badRequest().body(null);
        }
		List<Appointment> li=appService.getAppointmentsByStartDate(startDate);
		return new ResponseEntity<List<Appointment>>(li,HttpStatus.OK);
	}
	@GetMapping("api/appointment/physician/{patientId}/{date}")

    public ResponseEntity<List<Physician>> getPhysicianByPatientIdAndDate(

            @PathVariable("patientId") String patientId,

            @PathVariable("date") String date) {

        // Define the DateTimeFormatter to match the date format

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        LocalDateTime localDate;

        try {

            // Parse the date string to LocalDateTime

            localDate = LocalDateTime.parse(date, formatter);

        } catch (Exception e) {

            // Return bad request if date parsing fails

            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);

        }

        // Fetch physicians from the service

        List<Physician> physicians = appService.getPhysicianByPatientIdAndDate(patientId, localDate);

        // Return appropriate response based on the result

        if (physicians.isEmpty()) {

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        } else {

            return new ResponseEntity<>(physicians, HttpStatus.OK);

        }

    }

    @GetMapping("api/appointment/nurse/{patientId}/{date}")

    public ResponseEntity<List<Nurse>> getNursesByPatientIdAndDate(

            @PathVariable("patientId") String patientId,

            @PathVariable("date") String date) {

        // Define the DateTimeFormatter to match the date format

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        LocalDateTime localDate;

        try {

            // Parse the date string to LocalDateTime

            localDate = LocalDateTime.parse(date, formatter);

        } catch (Exception e) {

            // Return bad request if date parsing fails

            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);

        }

        // Fetch nurses from the service

        List<Nurse> nurses = appService.getNursesByPatientIdAndDate(patientId, localDate);

        // Return appropriate response based on the result

        if (nurses.isEmpty()) {

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        } else {

            return new ResponseEntity<>(nurses, HttpStatus.OK);

        }

    }	    

    @GetMapping("/api/appointment/date/{patientid}")

    public ResponseEntity<List<LocalDateTime>> getAppointmentDates(

            @PathVariable("patientid") int patientId) {

        // Fetch appointment dates from the service

        List<LocalDateTime> appointmentDates = appService.getAppointmentDatesByPatientId(patientId);

        // Return appropriate response based on the result

        if (appointmentDates.isEmpty()) {

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        } else {

            return new ResponseEntity<>(appointmentDates, HttpStatus.OK);

        }

    }

    @GetMapping("api/appointment/room/patientId/{patientid}/date/{date}")

    public ResponseEntity<String> getExaminationRoom(

            @PathVariable("patientid") int patientId,

            @PathVariable("date") String date) {

        try {

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

            LocalDateTime localDateTime = LocalDateTime.parse(date, formatter);

            String room = appService.getExaminationRoomByPatientIdAndDate(patientId, localDateTime.toLocalDate());

            return new ResponseEntity<>(room, HttpStatus.OK);

        } catch (DateTimeParseException e) {

            return new ResponseEntity<>("Invalid date format: " + e.getMessage(), HttpStatus.BAD_REQUEST);

        } catch (Exception e) {

            return new ResponseEntity<>("Error fetching data: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }


    @GetMapping("api/appointment/nurse/{patientid}")

    public ResponseEntity<List<Nurse>> getNursesByPatientId(@PathVariable("patientid") int patientId) {

        List<Nurse> nurses = appService.getNursesByPatientId(patientId);

        if (nurses.isEmpty()) {

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        } else {

            return new ResponseEntity<>(nurses, HttpStatus.OK);

        }

    }
    
    //Search a nurse detail by appointment id

    @RequestMapping(value="api/appointment/nurse/appointmentid/{appointmentid}",method=RequestMethod.GET)

    public ResponseEntity<Nurse> getNurseByAppointmentId(@PathVariable("appointmentid") Integer appointmentid) {

         Nurse nurse = appService.getNurseByAppointmentId(appointmentid);

        return new ResponseEntity<Nurse>(nurse, HttpStatus.OK);

}

      //given exception

// Search a examination room detail by appointment id

    @RequestMapping(value="api/appointment/examinationroom/{appointmentid}", method=RequestMethod.GET)

	public ResponseEntity<String> getExaminationRoom(@PathVariable("appointmentid") int appointmentid){

		    String room=appService.getExamintionRoomByappId(appointmentid);

		return new ResponseEntity<String>(room,HttpStatus.OK);

}	


       //Add a appointment detail to DB

     @PostMapping("api/appointment/post")

	  public ResponseEntity<String> postAppointment(@RequestBody Appointment a) {

    	 appService.postApp(a);

		return new ResponseEntity<String>("Record Created Successfully", HttpStatus.CREATED);

	}


          //Get about a patient checked by nurse by patient id

		@GetMapping("api/appointment/patient/{nurseid}/{patientid}")

		public ResponseEntity<Patient> getPatientByPatientIdAndNurseId(@PathVariable("nurseid") int nurseid, @PathVariable("patientid") int patientid) {

			Patient p = appService.getPatientByPatientIdAndNurseId(nurseid, patientid);

			return new ResponseEntity<Patient>(p, HttpStatus.OK);

		}


		   //Get a list of patient checked by nurse

		  @GetMapping("api/appointment/patient/nurseid/{nurseid}")

		    public ResponseEntity<HashSet<Patient> >getPatientsByNurse(@PathVariable("nurseid") Integer nurseid){

					HashSet<Patient> p = appService.getPateientsByNusreId(nurseid);

		 	return new ResponseEntity<HashSet<Patient>>(p,HttpStatus.OK);

		    }    


		  //Get a list of patient checked by Nurse on particular date

    @RequestMapping(value="api/appointment/patient/nurseid/{nurseid}/date/{date}", method=RequestMethod.GET)

      public ResponseEntity<HashSet<Patient>> getAllPatientsByNurseAndDate(@PathVariable("nurseid") int nurseid ,@PathVariable("date") LocalDate date){

    	HashSet<Patient> li=appService.getPatientsBynurseandDate(nurseid,date);

    			return new ResponseEntity<HashSet<Patient>>(li,HttpStatus.OK);

    }


       //given exception

    //Get a list of room details by Nurse id on a particular date

    @GetMapping("api/appointment/room/nurseid/{nurseid}/{date}")

    public ResponseEntity<List<Room>> getAllRoomDetails(@PathVariable("nurseid") int nurseid ,@PathVariable("date") LocalDateTime date)

    {

    	List<Room> r = appService.getRoomList(nurseid, date);

    	return new ResponseEntity<List<Room>>(r, HttpStatus.OK);

    }
//    @PutMapping("api/appointment/room/{appointmentid}")
//	public ResponseEntity<Appointment> updateRoomByAppointmentId(@PathVariable("appointmentid") Integer appointmentid,  @RequestBody Map<String, String> reqBody1) {
//		String newExaminationRoom = reqBody1.get("newExaminationRoom");
//		System.out.println(newExaminationRoom);
//		Appointment a = appService.updateExaminationRoom(appointmentid, newExaminationRoom);
//		return new ResponseEntity<Appointment>(a, HttpStatus.OK);
//		
//	}
    @PutMapping("api/appointment/room/{newExaminationRoom}/{appointmentid}")
	public ResponseEntity<Appointment> updateRoomByAppointmentId(
	        @PathVariable("appointmentid") Integer appointmentid,
	        @PathVariable String newExaminationRoom) {
	    System.out.println(newExaminationRoom);
	    Appointment a = appService.updateExaminationRoom(appointmentid, newExaminationRoom);
	    return new ResponseEntity<>(a, HttpStatus.OK);
	}
 
 

}
