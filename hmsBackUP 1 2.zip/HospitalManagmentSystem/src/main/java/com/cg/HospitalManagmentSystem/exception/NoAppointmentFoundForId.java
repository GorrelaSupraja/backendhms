package com.cg.HospitalManagmentSystem.exception;


public class NoAppointmentFoundForId extends RuntimeException{
	public NoAppointmentFoundForId(String msg) {
		super(msg);
	}
}
