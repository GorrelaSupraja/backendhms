package com.cg.HospitalManagmentSystem.serviceImpl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.cg.HospitalManagmentSystem.exception.PatientIdNotFoundException;
import com.cg.HospitalManagmentSystem.exception.PhysicianIdNotFoundException;
import com.cg.HospitalManagmentSystem.model.Patient;
import com.cg.HospitalManagmentSystem.model.Physician;
 
import com.cg.HospitalManagmentSystem.repository.PatientRepository;
import com.cg.HospitalManagmentSystem.repository.PhysicianRepository;
import com.cg.HospitalManagmentSystem.service.HMSPatientService;
 

import lombok.NoArgsConstructor;
 
@Service
@NoArgsConstructor
public class HMSPatientServiceImpl implements HMSPatientService{

	@Autowired 
	PatientRepository patientRepository;
	@Autowired
	PhysicianRepository physicianRepository;

      @Override
	  public List<Patient> getAllPatients() {
	       return patientRepository.findAll();
	    }
	 @Override
	  public List<Patient> getPatientsByPhysicianId(int physicianId) {
		   Physician physician = physicianRepository.findById(physicianId).orElse(null);
		   if (physician == null) throw new PhysicianIdNotFoundException(physicianId + " Physician not found!");
		   return patientRepository.findByPcp(physician);
		}
	 @Override
	  public Patient getPatientByPhysicianIdAndPatientId(int physicianId, int patientId) {
	       Physician physician = physicianRepository.findById(physicianId).orElse(null);
	       if (physician == null) {
	            return null;
	       }
 
	       Patient patient = patientRepository.findById(patientId).orElse(null);
	       if (patient != null && patient.getPcp().equals(physician)) {
	            return patient;
	       } else {
	            return null;
	       }
	    }
	   @Override	
	   public int getPatientInsuranceByPatientId(int patientId) {
		      Patient patient = patientRepository.findById(patientId).orElse(null);
		      if (patient == null) throw new PatientIdNotFoundException(patientId + " Patient not found");
		      return patient.getInsuranceID();
		   }
	   @Override   
	   public List<Physician> getPhysiciansByPatientId(int patientId) {
		     Patient patient = patientRepository.findById(patientId).orElse(null);
		     if (patient == null) throw new PatientIdNotFoundException(patientId + " Patient not found");

		        // Assuming a Patient is associated with multiple physicians via appointments
		      return patient.getAppointments().stream()
		             .map(appointment -> appointment.getPhysician())
		             .distinct()
		             .collect(Collectors.toList());
		   }
	   @Override
	   public Patient addPatient(Patient patient) {
		       return patientRepository.save(patient);
		    }
       @Override
	   public boolean updateAddress(int ssn, String address) {
	        return patientRepository.findById(ssn)
	               .map(patient -> {
	                patient.setAddress(address);
	                patientRepository.save(patient);
	                return true;
	             }).orElse(false);
	       }
       @Override
	   public String updatePhone(int ssn, String newPhone) {
		        Optional<Patient> optionalPatient = patientRepository.findBySsn(ssn);
		        if (optionalPatient.isPresent()) {
		            Patient patient = optionalPatient.get();
		            patient.setPhone(newPhone);
		            patientRepository.save(patient);
		            return "Phone updated successfully";
		        } else {
		            return "Patient not found";
		        }
		   }

}