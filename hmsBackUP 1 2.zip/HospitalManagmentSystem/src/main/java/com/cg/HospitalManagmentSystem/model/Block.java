package com.cg.HospitalManagmentSystem.model;

import java.util.List;


import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table (name = "Block")
public class Block {
    @EmbeddedId
    private BlockId id;
    
    @OneToMany(mappedBy = "block")
    private List<Room> rooms;

    @OneToMany(mappedBy = "block")
    private List<On_Call> onCalls;

	@Override
	public String toString() {
		return "Block [id=" + id + "]";
	}
    
    
}
