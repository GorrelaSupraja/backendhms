package com.cg.HospitalManagmentSystem.model;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table (name = "Undergoes")
public class Undergoes {
	@EmbeddedId
    private UndergoesId id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Patient", referencedColumnName = "SSN", insertable = false, updatable = false)
    private Patient patient;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Procedures", referencedColumnName = "Code", insertable = false, updatable = false)
    private Procedures procedures;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Stay", referencedColumnName = "StayID", insertable = false, updatable = false)
    private Stay stay;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Physician", referencedColumnName = "EmployeeID", insertable = false, updatable = false)
    private Physician physician;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "AssistingNurse", referencedColumnName = "EmployeeID", insertable = false, updatable = false)
    private Nurse assistingNurse;

	@Override
	public String toString() {
		return "Undergoes [id=" + id + "]";
	}
    
    
}
