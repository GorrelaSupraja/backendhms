package com.cg.HospitalManagmentSystem.exception;


public class DepartmentIdNotFoundException extends RuntimeException
{
	public DepartmentIdNotFoundException(String msg)
	{
		super(msg);
	}

}
