package com.cg.HospitalManagmentSystem.service;

import java.util.List;

import com.cg.HospitalManagmentSystem.model.Procedures;

public interface HMSProceduresService
{
	public List<Procedures> getAllProcedures();
	public Procedures getProceduresById(int procedureId);
	public Procedures getProcedureByName(String ProcedureName);
	public Procedures updateProcedureCost(Integer id, Double cost);
	public Procedures updateProcedureName(Integer id, String name);
	public Procedures addProcedure(Procedures procedure);
}
