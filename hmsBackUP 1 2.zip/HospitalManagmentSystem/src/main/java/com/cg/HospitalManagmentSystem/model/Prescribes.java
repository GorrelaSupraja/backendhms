package com.cg.HospitalManagmentSystem.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table (name = "Prescribes")
public class Prescribes {
	@EmbeddedId
    private PrescribesId id;

    @ManyToOne
    @MapsId("physician")
    @JoinColumn(name = "Physician", referencedColumnName = "employeeID")
    private Physician physician;

    @ManyToOne
    @MapsId("patient")
    @JoinColumn(name = "Patient", referencedColumnName = "ssn")
    private Patient patient;

    @ManyToOne
    @MapsId("medication")
    @JoinColumn(name = "Medication", referencedColumnName = "code")
    private Medication medication;

    @Column(name = "Date", nullable = false, insertable = false, updatable = false)
    private LocalDateTime date;

    @ManyToOne
    @JoinColumn(name = "Appointment", referencedColumnName = "appointmentID")
    private Appointment appointment;

    @Column(nullable = false, length = 30, name = "Dose")
    private String dose;

	@Override
	public String toString() {
		return "Prescribes [id=" + id + ", date=" + date + ", dose=" + dose + "]";
	}    
}
