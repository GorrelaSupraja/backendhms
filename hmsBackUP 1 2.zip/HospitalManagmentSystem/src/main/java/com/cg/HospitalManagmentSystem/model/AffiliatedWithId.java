package com.cg.HospitalManagmentSystem.model;
 
import java.io.Serializable;
 
import jakarta.persistence.Embeddable;
 
@Embeddable
public class AffiliatedWithId implements Serializable {
    private Integer physician;
    private Integer department;
 
    // Default Constructor
    public AffiliatedWithId() { }
 
    // Parameterized Constructor
    public AffiliatedWithId(Integer physician, Integer department) {
        this.physician = physician;
        this.department = department;
    }
 
    // Getter for physician
    public Integer getPhysician() {
        return physician;
    }
 
    // Setter for physician
    public void setPhysician(Integer physician) {
        this.physician = physician;
    }
 
    // Getter for department
    public Integer getDepartment() {
        return department;
    }
 
    // Setter for department
    public void setDepartment(Integer department) {
        this.department = department;
    }
 
    // toString method
    @Override
    public String toString() {
        return "AffiliatedWithId [physician=" + physician + ", department=" + department + "]";
    }
}
  
 
   