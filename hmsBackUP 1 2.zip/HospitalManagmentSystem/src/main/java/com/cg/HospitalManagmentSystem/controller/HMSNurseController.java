package com.cg.HospitalManagmentSystem.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.HospitalManagmentSystem.model.Nurse;
import com.cg.HospitalManagmentSystem.service.HMSNurseService;


@RestController
@Transactional
public class HMSNurseController {
	
	@Autowired
	private HMSNurseService nurseservice;
	
	
	      //Add a nurse detail to DB
		@PostMapping("/api/nurse")
		 public ResponseEntity<String> createNurse(@RequestBody Nurse nurse) {
		       
		       nurseservice.saveNurse(nurse);
		        return new ResponseEntity<String>("Record Created Successfully", HttpStatus.CREATED);
	  	    }
		
	@GetMapping("/api/nurse/")
	public ResponseEntity<List<Nurse>> getllNurse(){
		 List<Nurse> li =nurseservice.getAll();
		 return new ResponseEntity<List<Nurse>>(li,HttpStatus.OK);
	}
	     //given exception
	  //Get a detail of nurse by employeeid
	@RequestMapping(value="api/nurse/{empid}", method=RequestMethod.GET)
	public ResponseEntity<Nurse> getNurseById(@PathVariable("empid") int empid){
		Nurse nurse= nurseservice.getById(empid);
		return new ResponseEntity<Nurse>(nurse,HttpStatus.OK);
	}
	       //given exception
	   //Get position of nurse by employeeid
	@RequestMapping(value="api/nurse/position/{empid}", method=RequestMethod.GET)
	public ResponseEntity<String> getPosById(@PathVariable("empid") int empid){
		    String pos=nurseservice.getPosById(empid);
		return new ResponseEntity<String>(pos,HttpStatus.OK);
	}
	
	
	   //Get about a nurse is registered or not
	@RequestMapping(value="api/nurse/registered/{empid}", method=RequestMethod.GET)
	public ResponseEntity<Boolean>  getregister(@PathVariable("empid") int empid){
		    boolean pos=nurseservice.findRegister(empid);
			return new ResponseEntity<Boolean>(pos,HttpStatus.OK);
	} 
			
		 
	
	
	
	  //Update the value of registered by employeeid 
	@RequestMapping(value="api/nurse/registered/{empid}",method=RequestMethod.PUT)
    public ResponseEntity<Nurse> updateNurseRegistrationStatus( @PathVariable("empid") int empid,@RequestBody Nurse nurse )
    {
		Nurse existingNurse = nurseservice.getById(empid);

        existingNurse.setRegistered(nurse.getRegistered());
        Nurse updatedNurse = nurseservice.saveNurse(existingNurse);
        return new ResponseEntity<>(updatedNurse, HttpStatus.OK);
    }
	
	
	
      
	
	  //Update the value of SSN by empid      
	@PutMapping(value="api/nurse/ssn/{ssn}/{empid}")
	public ResponseEntity<Nurse> updateNurse(@PathVariable("empid") Integer empid,@PathVariable Integer ssn) {
	    // Find the existing nurse by empid
	    Nurse existingNurse = nurseservice.getById(empid);
	    
	    // If the nurse does not exist, return a 404 NOT FOUND response
	    if (existingNurse == null) {
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND);  // No nurse found
	    }
	    
	    // If the nurse exists, update their SSN
	    existingNurse.setSsn(ssn);
	    
	    // Save the updated nurse object
	    Nurse updatedNurse = nurseservice.updateSSN(empid,existingNurse);
	    
	    // Return the updated nurse object with a 200 OK status
	    return new ResponseEntity<>(updatedNurse, HttpStatus.OK);
	}


	
	
	
	

}
