package com.cg.HospitalManagmentSystem.exception;

public class PhysiciansNotFoundException extends RuntimeException{
	public PhysiciansNotFoundException(String msg)
	{
		super(msg);
	}

}
