package com.cg.HospitalManagmentSystem.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cg.HospitalManagmentSystem.exception.ProcedureIdNotFoundException;
import com.cg.HospitalManagmentSystem.exception.ProcedureNameNotFoundException;
import com.cg.HospitalManagmentSystem.model.Procedures;
import com.cg.HospitalManagmentSystem.repository.ProceduresRepository;
import com.cg.HospitalManagmentSystem.service.HMSProceduresService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class HMSProceduresServiceImpl implements HMSProceduresService{

	private ProceduresRepository prorepo;
	
	public List<Procedures> getAllProcedures()
	{
		return prorepo.findAll();	
	}
	
	public Procedures getProceduresById(int procedureId)
	{
		return prorepo.findById(procedureId).get();
	}
	
	public Procedures getProcedureByName(String ProcedureName)
	{
		Procedures pro=prorepo.findByName(ProcedureName);
		if(pro==null)
		{
			throw new ProcedureNameNotFoundException("No procedures found for this name: "+ ProcedureName );
		}
		return prorepo.findByName(ProcedureName);
		
	}
	public Procedures updateProcedureCost(Integer id, Double newCost)
	{
		Optional<Procedures> procedure = prorepo.findById(id);
        if(procedure.isEmpty())
        {
        	throw new ProcedureIdNotFoundException("Procedure not found with id: " + id);
        }
        procedure.get().setCost(newCost);
        return prorepo.save(procedure.get());
    }
	public Procedures updateProcedureName(Integer id, String newName)
	{
		Procedures procedure=prorepo.findById(id).get();
		procedure.setName(newName);
		return prorepo.save(procedure);
	}
	public Procedures addProcedure(Procedures procedure) 
	{
        return prorepo.save(procedure);
    }
}
