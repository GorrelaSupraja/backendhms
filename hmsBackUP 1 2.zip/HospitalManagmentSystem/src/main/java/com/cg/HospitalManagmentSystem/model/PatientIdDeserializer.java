package com.cg.HospitalManagmentSystem.model;

import java.io.IOException;

import org.hibernate.annotations.Comment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.HospitalManagmentSystem.repository.PatientRepository;
import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

@Component
public class PatientIdDeserializer extends JsonDeserializer<Patient> {
	@Autowired PatientRepository patRepo;

	@Override
	public Patient deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JacksonException {
		
		Integer ssn = p.getIntValue();
		
		return patRepo.findById(ssn).orElse(null);
	}

}
