package com.cg.HospitalManagmentSystem.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;

import com.cg.HospitalManagmentSystem.model.Appointment;
import com.cg.HospitalManagmentSystem.model.Nurse;
import com.cg.HospitalManagmentSystem.model.Patient;
import com.cg.HospitalManagmentSystem.model.Physician;
import com.cg.HospitalManagmentSystem.model.Room;

public interface HMSAppointmentService {
	

	public Appointment updateExaminationRoom(Integer appointmentid, String newExaminationRoom);
	public HashSet<Patient> getPatientCheckedByPhysician(int physicianid);
	public HashSet<Patient> getPatientCheckedByPhysicianOnDate(int physicianid, LocalDate date);
	public Patient getPatientByPatientIdAndPhysicianId(int physicianid, int patientid);
	public Patient getPatientByAppointment(int appointmentid);
	public Physician getPhysicianByAppointment(int appointmentid);
	public List<Room> getRoomByPhysicianIdOnDate(int physicianid, LocalDateTime date);
	public List<Appointment> getAllAppointments();
	public List<Appointment> getAppointmentsByStartDate(LocalDateTime startDate);
	public List<Physician> getPhysicianByPatientIdAndDate(String patientId, LocalDateTime date);
    public List<Nurse> getNursesByPatientIdAndDate(String patientId, LocalDateTime date);
    public List<LocalDateTime> getAppointmentDatesByPatientId(int patientId);  
    public String getExaminationRoomByPatientIdAndDate(int patientId, LocalDate date);
    public Nurse getNurseByPatientIdAndDate(int patientId, LocalDateTime dateTime);
    public List<Nurse> getNursesByPatientId(int patientId);
    public Nurse getNurseByAppointmentId(Integer appointmentId);
	public String getExamintionRoomByappId(int id);
	public HashSet<Patient> getPateientsByNusreId(int nurseid);
	public Patient getPatientByPatientIdAndNurseId(int nurseid, int patientid);
	public void postApp(Appointment a);
	public HashSet<Patient> getPatientsBynurseandDate(int nurseid,LocalDate starto);
	public List<Room> getRoomList(int nurseId, LocalDateTime date); 
	public List<Appointment> getAll();

		
 

}
