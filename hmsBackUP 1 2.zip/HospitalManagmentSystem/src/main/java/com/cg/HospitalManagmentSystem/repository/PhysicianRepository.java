package com.cg.HospitalManagmentSystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.cg.HospitalManagmentSystem.model.Physician;
@CrossOrigin("*")
@Repository
public interface PhysicianRepository extends JpaRepository<Physician, Integer> {
	public Physician findByName(String name);
	public List<Physician> findByPosition(String pos);
}
