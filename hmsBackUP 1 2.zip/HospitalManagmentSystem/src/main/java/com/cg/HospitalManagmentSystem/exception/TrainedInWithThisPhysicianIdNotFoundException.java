package com.cg.HospitalManagmentSystem.exception;

public class TrainedInWithThisPhysicianIdNotFoundException extends RuntimeException 
{
	public TrainedInWithThisPhysicianIdNotFoundException(String msg)
	{
		super(msg);
	}

}
