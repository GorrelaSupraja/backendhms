package com.cg.HospitalManagmentSystem.serviceImpl;



import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.HospitalManagmentSystem.exception.AffiliatedWithExistsException;
import com.cg.HospitalManagmentSystem.exception.NoAffiliationsFoundException;
import com.cg.HospitalManagmentSystem.exception.PhysiciansNotFoundException;
import com.cg.HospitalManagmentSystem.model.AffiliatedWithId;
import com.cg.HospitalManagmentSystem.model.Affiliated_With;
import com.cg.HospitalManagmentSystem.model.Department;
import com.cg.HospitalManagmentSystem.model.Physician;
import com.cg.HospitalManagmentSystem.repository.Affiliated_With_Repository;
import com.cg.HospitalManagmentSystem.repository.DepartmentRepository;
import com.cg.HospitalManagmentSystem.repository.PhysicianRepository;
import com.cg.HospitalManagmentSystem.service.HMSAffiliatedWithService;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Service
@Getter
@Setter
@AllArgsConstructor
public class HMSAffiliatedWithServiceImpl implements HMSAffiliatedWithService{
	
	private Affiliated_With_Repository affRepo;
	
	private PhysicianRepository phyRepo;
	
	private DepartmentRepository depRepo;
	
	
	
	
	@Override
	public Affiliated_With createAffiliatedWith(Affiliated_With affObj) {
		
		AffiliatedWithId id=affObj.getId();
		if(affRepo.existsById(id))
		{
			throw new AffiliatedWithExistsException("Affiliated With Already exists");
		}
		return affRepo.save(affObj);
	}
	
	
	@Override
	//search a list of physicians affiliatedwith deptid
	public List<Physician> getPhysiciansByDeptId(Integer deptid) {
		List<Integer> PhysicianIds=affRepo.findByDepartment(deptid);
		List<Physician> phyList=new ArrayList<>();
		for(Integer i:PhysicianIds) {
			phyList.add(phyRepo.findById(i).get());
		}
		if(phyList.isEmpty())
		{
			throw new PhysiciansNotFoundException("No Physicians Found");
		}
		return phyList;
	}
	
	@Override
	public List<Department> getDepartmentsByPhyId(Integer phyId) {
		List<Affiliated_With> affList=affRepo.findByPhysician(phyId);
        List<Integer>  DepartmentIds= new ArrayList<>();
        for(Affiliated_With aff:affList) {
        	DepartmentIds.add(aff.getId().getDepartment());
        }
        List<Department> depList=new LinkedList<>();
        for(Integer i:DepartmentIds) {
        	depList.add(depRepo.findById(i).get());
        }
        
        return depList;
    }

	@Override
	public Integer findPhyCountByDeptId(Integer deptId) {
		return affRepo.findPhyCountByDeptId(deptId);
	}

	@Override
	public boolean findPrimaryAffByPhyId(Integer physicianId) 
	{
		
		List<Affiliated_With> affList=affRepo.findByPhysician(physicianId);
		List<Boolean> primaryAffList=new ArrayList<>();
		if(affList.isEmpty()||affList==null)
		{
			throw new NoAffiliationsFoundException("No affiliations found for physician ID: " + physicianId);
		}
		
		for(Affiliated_With aff:affList) 
		{
			primaryAffList.add(aff.getPrimaryAffiliation());
		}
		
		if(primaryAffList.size()==1) 
		{
			return primaryAffList.get(0);
			
		}
		else {
			return false;
		}
		
		
	}

	@Override
	public List<Affiliated_With> getall() {
		
		return affRepo.findAll();
	}

	

}
