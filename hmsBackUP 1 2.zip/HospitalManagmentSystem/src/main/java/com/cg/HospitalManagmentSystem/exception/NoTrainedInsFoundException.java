package com.cg.HospitalManagmentSystem.exception;

public class NoTrainedInsFoundException extends RuntimeException{
	public NoTrainedInsFoundException(String msg)
	{
		super(msg);
	}

}
