package com.cg.HospitalManagmentSystem.exception;

public class PositionNotFoundForPosition extends RuntimeException {
	public PositionNotFoundForPosition(String msg) {
		super(msg);
	}
}
