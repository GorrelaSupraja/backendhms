package com.cg.HospitalManagmentSystem.model;
 
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import java.util.List;
 
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table (name = "Patient")
public class Patient {
    @Id
    @Column(name = "SSN")
    private Integer ssn;
 
    @Column(nullable = false, length = 30, name = "Name")
    private String name;
 
    @Column(nullable = false, length = 30, name = "Address")
    private String address;
 
    @Column(nullable = false, length = 30, name = "Phone")
    private String phone;
 
    @Column(nullable = false, name = "InsuranceID")
    private Integer insuranceID;
    @ManyToOne
    @JoinColumn(name = "PCP", referencedColumnName = "employeeID")
    @JsonSerialize(using = PcpIdSerializer.class)
    private Physician pcp;
    @OneToMany(mappedBy = "patient", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Appointment> appointments;
    @OneToMany(mappedBy = "patient", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Prescribes> prescriptions;
    @OneToMany(mappedBy = "patient")
    @JsonIgnore
    private List<Stay> stays;
    @OneToMany(mappedBy = "patient")
    @JsonIgnore
    private List<Undergoes> undergoes;
 
	@Override
	public String toString() {
		return "Patient [ssn=" + ssn + ", name=" + name + ", address=" + address + ", phone=" + phone + ", insuranceID="
				+ insuranceID + ", pcp=" + pcp + "]";
	}
	public Integer getSsn() {
	    return ssn;
	}
 
	public void setSsn(Integer ssn) {
	    this.ssn = ssn;
	}
 
	public String getName() {
	    return name;
	}
 
	public void setName(String name) {
	    this.name = name;
	}
 
	public String getAddress() {
	    return address;
	}
 
	public void setAddress(String address) {
	    this.address = address;
	}
 
	public String getPhone() {
	    return phone;
	}
 
	public void setPhone(String phone) {
	    this.phone = phone;
	}
 
	public Integer getInsuranceID() {
	    return insuranceID;
	}
 
	public void setInsuranceID(Integer insuranceID) {
	    this.insuranceID = insuranceID;
	}
 
	public Physician getPcp() {
	    return pcp;
	}
 
	public void setPcp(Physician pcp) {
	    this.pcp = pcp;
	}
 
	public List<Appointment> getAppointments() {
	    return appointments;
	}
 
	public void setAppointments(List<Appointment> appointments) {
	    this.appointments = appointments;
	}
 
	public List<Prescribes> getPrescriptions() {
	    return prescriptions;
	}
 
	public void setPrescriptions(List<Prescribes> prescriptions) {
	    this.prescriptions = prescriptions;
	}
 
	public List<Stay> getStays() {
	    return stays;
	}
 
	public void setStays(List<Stay> stays) {
	    this.stays = stays;
	}
 
	public List<Undergoes> getUndergoes() {
	    return undergoes;
	}
 
	public void setUndergoes(List<Undergoes> undergoes) {
	    this.undergoes = undergoes;
	}
 
}