package com.cg.HospitalManagmentSystem.serviceImpl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.cg.HospitalManagmentSystem.exception.NoProceduresFoundException;
import com.cg.HospitalManagmentSystem.exception.PhysicianIdNotFoundException;
import com.cg.HospitalManagmentSystem.exception.TrainedInWithThisPhysicianIdNotFoundException;
import com.cg.HospitalManagmentSystem.model.Physician;
import com.cg.HospitalManagmentSystem.model.Procedures;
import com.cg.HospitalManagmentSystem.model.Trained_In;
import com.cg.HospitalManagmentSystem.repository.ProceduresRepository;
import com.cg.HospitalManagmentSystem.repository.Trained_In_Repository;
import com.cg.HospitalManagmentSystem.service.HMSTrainedInService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class HMSTrainedInServiceImpl implements HMSTrainedInService{
	
	private Trained_In_Repository trainrepo;
	
	private ProceduresRepository proRepo;
	
	public List<Procedures> getTreatmentsByPhysician(Integer physicianId)
	{
		  List<Trained_In> trainedInList = trainrepo.findByPhysician(physicianId);
		  List<Procedures> treatments = new ArrayList<>();
		  for (Trained_In trainedIn : trainedInList) 
		  {
			  treatments.add(trainedIn.getTreatment());
		  }
		  if(trainedInList.isEmpty())
		  {
			  throw new TrainedInWithThisPhysicianIdNotFoundException("No TrainedIn found for this PhysicianID: "+physicianId);
		  }
		  return treatments;

	}
	
	public List<Physician> getPhysicianByTreatment(Integer treatmentCode)
	{
		List<Trained_In> trainedInList =trainrepo.findByTreatmentCode(treatmentCode);
		List<Physician> physicians = new ArrayList<>();
        for (Trained_In trainedIn : trainedInList) 
        {
            physicians.add(trainedIn.getPhysician());
        }
      if(physicians.isEmpty())
        {
        	throw new PhysicianIdNotFoundException("No Physicians found");
        }
        
        return physicians;
	}
	
	public List<Procedures> getCertifiedProcedures()
	{
        List<Trained_In> trainedInList = trainrepo.findDistinctByTreatmentIsNotNull(); 
        Set<Procedures> uniqueProcedures = new HashSet<>();
        for (Trained_In trainedIn : trainedInList) 
        {
         uniqueProcedures.add(trainedIn.getTreatment());
        }
        List<Procedures> proceduresList = new ArrayList<>(uniqueProcedures);
        return proceduresList;
	}
	
	 public Trained_In saveTrainedIn(Trained_In trainedIn)
	 {
		 return trainrepo.save(trainedIn);
	 }
	 
	 public List<Trained_In> findAll()
	 {
		 return trainrepo.findAll();
	 }
	 
	 public List<Procedures> getProceduresWithExpiringCertifications(Integer physicianId) 
	 {
		 List<Trained_In> trainedList=trainrepo.findProceduresWithExpiringCertifications(physicianId);
		 List<Integer> codes=new ArrayList<>();
		 for(Trained_In t:trainedList) {
			 codes.add(t.getTreatment().getCode());
		 }
		 List<Procedures> proList=new ArrayList<>();
		 for(Integer i:codes) {
			 proList.add(proRepo.findById(i).get());
		 }
		 if(proList.isEmpty())
		 {
			 throw new NoProceduresFoundException("No procedures found with expiring certificates for this physician ID: "+ physicianId);
		 }	 
		 return proList;
	 }
	 public Boolean updateCertificationExpiry(int physicianid, int procedureid, LocalDateTime newCertificationExpiry) {

			Trained_In t = trainrepo.findByPhysicianAndTreatment(physicianid, procedureid);

			if (t.equals(null)) return false;

			t.setCertificationExpires(newCertificationExpiry);

			trainrepo.save(t);

			return true;

		}


}
