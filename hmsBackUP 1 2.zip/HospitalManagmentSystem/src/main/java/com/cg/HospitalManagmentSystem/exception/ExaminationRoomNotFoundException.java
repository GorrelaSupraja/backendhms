package com.cg.HospitalManagmentSystem.exception;

public class ExaminationRoomNotFoundException extends RuntimeException{

	public ExaminationRoomNotFoundException(String msg)
	{
		super(msg);
	}

}
