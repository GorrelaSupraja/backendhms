package com.cg.HospitalManagmentSystem.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@SuppressWarnings("serial")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Embeddable
public class UndergoesId implements Serializable {
	 @Column(name = "Patient")
	    private Integer patient;

	    @Column(name = "Procedures")
	    private Integer procedures;

	    @Column(name = "Stay")
	    private Integer stay;

	    @Column(name = "DateUndergoes")
	    private LocalDateTime dateUndergoes;
}
