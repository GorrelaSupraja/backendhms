package com.cg.HospitalManagmentSystem.exception;

public class DepartmentExistsException extends RuntimeException{
	public DepartmentExistsException(String msg)
	{
		super(msg);
	}

}
