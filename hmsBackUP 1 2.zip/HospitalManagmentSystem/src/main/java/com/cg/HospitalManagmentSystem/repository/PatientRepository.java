package com.cg.HospitalManagmentSystem.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.cg.HospitalManagmentSystem.model.Patient;
import com.cg.HospitalManagmentSystem.model.Physician;
@CrossOrigin("*")
@Repository
public interface PatientRepository extends JpaRepository<Patient, Integer> {


	List<Patient> findByPcp(Physician physician);

    Optional<Patient> findBySsn(int ssn);

    Optional<Patient> findById(int ssn);
 
}
