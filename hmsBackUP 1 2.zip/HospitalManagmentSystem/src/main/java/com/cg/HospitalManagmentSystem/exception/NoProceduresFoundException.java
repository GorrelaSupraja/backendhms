package com.cg.HospitalManagmentSystem.exception;

public class NoProceduresFoundException extends RuntimeException 
{

	public NoProceduresFoundException(String msg)
	{
		super(msg);
	}
}
