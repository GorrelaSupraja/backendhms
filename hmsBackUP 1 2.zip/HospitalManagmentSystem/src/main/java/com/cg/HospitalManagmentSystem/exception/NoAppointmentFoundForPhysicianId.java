package com.cg.HospitalManagmentSystem.exception;

public class NoAppointmentFoundForPhysicianId extends RuntimeException{
	public NoAppointmentFoundForPhysicianId(String msg) {
		super(msg);
	}
}
