package com.cg.HospitalManagmentSystem.exception;

public class PhysicianIdNotFoundException extends RuntimeException
{
	public PhysicianIdNotFoundException(String msg) 
	{
		super(msg);
	}

}
