package com.cg.HospitalManagmentSystem.model;
 
import java.util.List;
 
import com.fasterxml.jackson.annotation.JsonIgnore;
 
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
 
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table (name = "Nurse")
public class Nurse {
    @Id
    @Column(name = "EmployeeID")
    private Integer employeeID;
 
    @Column(nullable = false, length = 30, name = "Name")
    private String name;
 
    @Column(nullable = false, length = 30, name = "Position")
    private String position;
 
    @Column(nullable = false, name = "Registered")
    private Boolean registered;
 
    @Column(nullable = false, name = "SSN")
    private Integer ssn;
    @OneToMany(mappedBy = "prepNurse", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Appointment> appointments;
    @OneToMany(mappedBy = "nurse", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<On_Call> onCalls;
    @OneToMany(mappedBy = "assistingNurse")
    @JsonIgnore
    private List<Undergoes> undergoes;
    public Integer getEmployeeID() {
        return employeeID;
    }
 
    public void setEmployeeID(Integer employeeID) {
        this.employeeID = employeeID;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
 
    public String getPosition() {
        return position;
    }
 
    public void setPosition(String position) {
        this.position = position;
    }
 
    public Boolean getRegistered() {
        return registered;
    }
 
    public void setRegistered(Boolean registered) {
        this.registered = registered;
    }
 
    public Integer getSsn() {
        return ssn;
    }
 
    public void setSsn(Integer ssn) {
        this.ssn = ssn;
    }
 
    public List<Appointment> getAppointments() {
        return appointments;
    }
 
    public void setAppointments(List<Appointment> appointments) {
        this.appointments = appointments;
    }
 
    public List<On_Call> getOnCalls() {
        return onCalls;
    }
 
    public void setOnCalls(List<On_Call> onCalls) {
        this.onCalls = onCalls;
    }
 
    public List<Undergoes> getUndergoes() {
        return undergoes;
    }
 
    public void setUndergoes(List<Undergoes> undergoes) {
        this.undergoes = undergoes;
    }

	public Nurse(Integer employeeID) {
		super();
		this.employeeID = employeeID;
	}
 
}