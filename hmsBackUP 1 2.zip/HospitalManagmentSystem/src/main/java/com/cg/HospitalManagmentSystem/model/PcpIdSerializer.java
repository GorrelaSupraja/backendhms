package com.cg.HospitalManagmentSystem.model;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

public class PcpIdSerializer extends JsonSerializer<Physician>{

	@Override
	public void serialize(Physician value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
		gen.writeNumber(value.getEmployeeID());
		
	}

}
