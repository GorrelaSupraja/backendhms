package com.cg.HospitalManagmentSystem.serviceImpl;

import java.util.List;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cg.HospitalManagmentSystem.exception.DepartmentExistsException;
import com.cg.HospitalManagmentSystem.exception.DepartmentIdNotFoundException;
import com.cg.HospitalManagmentSystem.exception.DepartmentsNotFoundException;
import com.cg.HospitalManagmentSystem.exception.NoTrainedInsFoundException;
import com.cg.HospitalManagmentSystem.exception.PhysiciansNotFoundException;
import com.cg.HospitalManagmentSystem.model.*;
import com.cg.HospitalManagmentSystem.repository.DepartmentRepository;
import com.cg.HospitalManagmentSystem.repository.Trained_In_Repository;
import com.cg.HospitalManagmentSystem.service.HMSDepartmentService;

import lombok.AllArgsConstructor;
@Service
@AllArgsConstructor
public class HMSDepartmentServiceImpl implements HMSDepartmentService{
	
	private DepartmentRepository deptRepo;
	private Trained_In_Repository trainedInRepo;
	
	
	@Override
	public Department createDepartment(Department dept) 
	{
		
		int id=dept.getDepartmentID();
		if(deptRepo.existsById(id))
		{
			throw new DepartmentExistsException("Department Exists for this ID "+id);
		}
		
		return deptRepo.save(dept);
	}
	
	@Override
	public List<Department> getAllDepartments()
	{
		return deptRepo.findAll();
		
		
		
	}
	@Override
	public Department getDepartmentById(Integer departmentId) {
		Optional<Department> dept=deptRepo.findById(departmentId);
		if(dept.isEmpty()||dept==null) 
		{
			throw new DepartmentIdNotFoundException("Department Id "+departmentId+" Not Found ");
		}
		return dept.get();
		
	}
	@Override
	public Physician getHeadByDeptId(Integer departmentId) {
		Department dept=deptRepo.findById(departmentId).get();
		
		if(dept.getHead()==null) {
			throw new PhysiciansNotFoundException("Physician Not Found");
		}
		return dept.getHead();
	}
	
	@Override
	public List<Department> getDepartmentsByHead(Integer head)
	{
		List<Department> deptList=deptRepo.findByHeadId(head);
		if(deptList.isEmpty()||deptList==null) {
			throw new DepartmentsNotFoundException("No Departments for HeadId: "+head);
		}
		return deptList;
	}
	
	@Override
	public boolean existsByPhysicianId(Integer physicianId) {
		return deptRepo.existsByPhysicianId(physicianId)>0;
	}
	@Override
	public List<Trained_In> findCertificationsByDeptid(Integer departmentId) {
		
		
		Department dept = deptRepo.findById(departmentId).get();
		Integer id = dept.getHead().getEmployeeID();
		List<Trained_In> trainedList=trainedInRepo.getByPhysician(id);
		if(trainedList.isEmpty()) 
		{
			throw new NoTrainedInsFoundException("No Trained_In Found for Physician Id: "+id);
		}
		return trainedList;
		
	}

	@Override
	public Department updateHeadByDeptId(Integer departmentId, Physician updatedHead) 
	{
		Department existingDept=deptRepo.findById(departmentId).get();
		existingDept.setHead(updatedHead);
		return deptRepo.save(existingDept);
	}
	
	@Override
	public Department updateDepartmentName(Integer departmentId, String newDepartmentName)
	{
		Department dept=deptRepo.findById(departmentId).get();
		dept.setName(newDepartmentName);
		return deptRepo.save(dept);
	}
	

	
	

}
