package com.cg.HospitalManagmentSystem.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.HospitalManagmentSystem.model.Procedures;
import com.cg.HospitalManagmentSystem.service.HMSProceduresService;

import lombok.AllArgsConstructor;

@RestController
@Transactional
@AllArgsConstructor
public class HMSProceduresController { 

	private HMSProceduresService proService;
	
	
	@GetMapping("/api/procedure/")
	public ResponseEntity<List<Procedures>> getAllProcedures()
	{
		List<Procedures> li=proService.getAllProcedures();
		return new ResponseEntity<List<Procedures>>(li,HttpStatus.OK);
	}
	
	
	@GetMapping("/api/procedure/cost/{id}")
	public ResponseEntity<Procedures> getProcedureById(@PathVariable("id") int procedureId)
	{
		Procedures pro=proService.getProceduresById(procedureId);
		return new ResponseEntity<Procedures>(pro,HttpStatus.OK);
	}
	
	
//	created exception
	@GetMapping("/cost/{name}")
	public ResponseEntity<Procedures> getProceduresByName(@PathVariable("name") String procedureName)
	{
		Procedures pro=proService.getProcedureByName(procedureName);
		return new ResponseEntity<Procedures>(pro,HttpStatus.OK);
	}
	
//	created exception
	@PutMapping("/api/procedure/cost/{cost}/{id}")
	public ResponseEntity<Procedures> updateProcedureCost(@PathVariable("id") Integer id, @PathVariable("cost") Double cost)
	{
		
        Procedures pro= proService.updateProcedureCost(id, cost);
        return ResponseEntity.ok(pro);
    }
	
	
	@PutMapping("/api/procedure/name/{name}/{id}")
	public ResponseEntity<Procedures> updateProcedureName(@PathVariable("id") Integer id, @PathVariable("name") String name)
	{
		
		Procedures pro=proService.updateProcedureName(id, name);
		return ResponseEntity.ok(pro);
	}
	
	
	@PostMapping("/api/procedure")
	 public ResponseEntity<Procedures> addProcedure(@RequestBody Procedures procedure) 
	{
		Procedures savedProcedure = proService.addProcedure(procedure);
		return new ResponseEntity<>(savedProcedure, HttpStatus.CREATED);
	}
	
}