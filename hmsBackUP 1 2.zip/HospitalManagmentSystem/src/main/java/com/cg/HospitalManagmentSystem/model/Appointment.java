package com.cg.HospitalManagmentSystem.model;
 
import java.time.LocalDateTime;
import java.util.List;
 
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
 
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
 
@Entity
@Table(name = "Appointment")
public class Appointment {
    @Id
    @Column(name = "AppointmentID")
    private Integer appointmentID;
 
    @ManyToOne
    @JoinColumn(name = "Patient", referencedColumnName = "ssn")
    @JsonSerialize(using = PatientIdSerializer.class)
    @JsonDeserialize(using = PatientIdDeserializer.class)
    private Patient patient;
 
    @ManyToOne
    @JoinColumn(name = "PrepNurse", referencedColumnName = "employeeID")
    @JsonSerialize(using = NurseIdSerializer.class)
    @JsonDeserialize(using = NurseIdDeserialier.class)
    private Nurse prepNurse;
 
    @ManyToOne
    @JoinColumn(name = "Physician", referencedColumnName = "employeeID")
    @JsonSerialize(using = PcpIdSerializer.class)
    @JsonDeserialize(using = PhysicianIdDeserializer.class)
    private Physician physician;
 
    @Column(nullable = false, name = "Starto")
    private LocalDateTime start;
 
    @Column(nullable = false, name = "Endo")
    private LocalDateTime end;
 
    @Column(nullable = false, name = "ExaminationRoom")
    private String examinationRoom;
 
    @OneToMany(mappedBy = "appointment", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Prescribes> prescriptions;
 
    // Default Constructor
    public Appointment() {
    }
 
    // Parameterized Constructor
    public Appointment(Integer appointmentID, Patient patient, Nurse prepNurse, Physician physician, LocalDateTime start,
                       LocalDateTime end, String examinationRoom, List<Prescribes> prescriptions) {
        this.appointmentID = appointmentID;
        this.patient = patient;
        this.prepNurse = prepNurse;
        this.physician = physician;
        this.start = start;
        this.end = end;
        this.examinationRoom = examinationRoom;
        this.prescriptions = prescriptions;
    }
 
    // Getters and Setters
    public Integer getAppointmentID() {
        return appointmentID;
    }
 
    public void setAppointmentID(Integer appointmentID) {
        this.appointmentID = appointmentID;
    }
 
    public Patient getPatient() {
        return patient;
    }
 
    public void setPatient(Patient patient) {
        this.patient = patient;
    }
 
    public Nurse getPrepNurse() {
        return prepNurse;
    }
 
    public void setPrepNurse(Nurse prepNurse) {
        this.prepNurse = prepNurse;
    }
 
    public Physician getPhysician() {
        return physician;
    }
 
    public void setPhysician(Physician physician) {
        this.physician = physician;
    }
 
    public LocalDateTime getStart() {
        return start;
    }
 
    public void setStart(LocalDateTime start) {
        this.start = start;
    }
 
    public LocalDateTime getEnd() {
        return end;
    }
 
    public void setEnd(LocalDateTime end) {
        this.end = end;
    }
 
    public String getExaminationRoom() {
        return examinationRoom;
    }
 
    public void setExaminationRoom(String examinationRoom) {
        this.examinationRoom = examinationRoom;
    }
 
    public List<Prescribes> getPrescriptions() {
        return prescriptions;
    }
 
    public void setPrescriptions(List<Prescribes> prescriptions) {
        this.prescriptions = prescriptions;
    }
 
    // toString Method
    @Override
    public String toString() {
        return "Appointment [appointmentID=" + appointmentID + ", start=" + start + ", end=" + end
                + ", examinationRoom=" + examinationRoom + "]";
    }
}
 
