package com.cg.HospitalManagmentSystem.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.HospitalManagmentSystem.exception.PositionNotFoundForPosition;
import com.cg.HospitalManagmentSystem.model.Physician;
import com.cg.HospitalManagmentSystem.service.HMSPhysicianService;

@RestController
@Transactional
public class HMSPhysicianController {
	@Autowired HMSPhysicianService phyService;
	
	// getById()
	@GetMapping("/api/physician/empid/{empid}")
	public ResponseEntity<Physician> getById(@PathVariable int empid) {
		Physician res = phyService.getPhyById(empid);
		return new ResponseEntity<Physician>(res, HttpStatus.OK);
	}
	
	@GetMapping("/api/physician/name/{name}")
	public ResponseEntity<Physician> getByName(@PathVariable String name) {
		Physician res = phyService.getPhyByName(name);
		return new ResponseEntity<Physician>(res, HttpStatus.OK);
	}
	@GetMapping("/api/physician/position/{pos}")
	public ResponseEntity<List<Physician>> getByPosition(@PathVariable String pos) {
		List<Physician> res = phyService.getPhyByPos(pos);
		if (res.isEmpty()) throw new PositionNotFoundForPosition(pos + " NOt Found!");
		return new ResponseEntity<List<Physician>>(res, HttpStatus.OK);
	}
	
	@PostMapping("/api/physician/post")
	public ResponseEntity<String> postPhysician(@RequestBody Physician p) {
		phyService.addPhysician(p);
		return new ResponseEntity<String>("Record Created Successfully", HttpStatus.OK);
	}
	
	@PutMapping("/api/update/position/{position}/{employeeId}")
	public ResponseEntity<Physician> updatePhysicianPosition(@PathVariable("position") String position, @PathVariable("employeeId") Integer employeeId) {
		Physician p = phyService.updatePosition(position, employeeId);
		return new ResponseEntity<Physician>(p, HttpStatus.OK);
	}
	
	@PutMapping("/api/physician/update/name/{name}/{empid}")
	public ResponseEntity<Physician> updatePhysicianName(@PathVariable Integer empid, @PathVariable String name) {
		
		
		Physician p = phyService.updateName(empid, name);
		return new ResponseEntity<Physician>(p, HttpStatus.OK);
	}
	
	@PutMapping("/api/physician/update/ssn/{ssn}/{empid}")
	public ResponseEntity<Physician> updatePhysicianSsn(@PathVariable Integer empid, @PathVariable Integer ssn) {
		
		Physician p = phyService.updateSSN(empid, ssn);
		return new ResponseEntity<Physician>(p, HttpStatus.OK);
	}
	
	
	
}
