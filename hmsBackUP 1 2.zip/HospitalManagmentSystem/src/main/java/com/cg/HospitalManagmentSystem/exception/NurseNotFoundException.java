package com.cg.HospitalManagmentSystem.exception;


public class NurseNotFoundException extends RuntimeException
{
	public NurseNotFoundException(String msg)
	{
		super(msg);
	}

}
