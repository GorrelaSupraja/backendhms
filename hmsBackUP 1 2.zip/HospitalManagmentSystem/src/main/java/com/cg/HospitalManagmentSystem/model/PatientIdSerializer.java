package com.cg.HospitalManagmentSystem.model;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

public class PatientIdSerializer extends JsonSerializer<Patient> {

	@Override
	public void serialize(Patient value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
		gen.writeNumber(value.getSsn());
		
		/*Patient p = new Patient();
		p.setSsn(value.getSsn());
		p.setName(value.getName());
		p.setAddress(value.getAddress());
		p.setPhone(value.getPhone());
		p.setInsuranceID(value.getInsuranceID());
		p.setPcp(value.getPcp());
		gen.writeObject(p);*/
	}

}
