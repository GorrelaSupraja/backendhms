package com.cg.HospitalManagmentSystem.exception;

public class NoNurseFoundByPatientIdException extends RuntimeException{
	
	public NoNurseFoundByPatientIdException(String msg) {
		super(msg);
	}

}
