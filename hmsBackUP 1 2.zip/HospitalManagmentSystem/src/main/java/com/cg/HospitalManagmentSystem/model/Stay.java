package com.cg.HospitalManagmentSystem.model;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table (name = "Stay")
public class Stay {
	@Id
    @Column(name = "StayID")
    private Integer stayID;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Patient", referencedColumnName = "SSN", foreignKey = @ForeignKey(name = "fk_Stay_Patient_SSN"), nullable = false)
    private Patient patient;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Room", referencedColumnName = "RoomNumber", foreignKey = @ForeignKey(name = "fk_Stay_Room_Number"), nullable = false)
    private Room room;

    @Column(name = "StayStart", nullable = false)
    private LocalDateTime stayStart;

    @Column(name = "StayEnd", nullable = false)
    private LocalDateTime stayEnd;
    
    @OneToMany(mappedBy = "stay")
    private List<Undergoes> undergoes;

	@Override
	public String toString() {
		return "Stay [stayID=" + stayID + ", stayStart=" + stayStart + ", stayEnd=" + stayEnd + "]";
	}
    
    
}
