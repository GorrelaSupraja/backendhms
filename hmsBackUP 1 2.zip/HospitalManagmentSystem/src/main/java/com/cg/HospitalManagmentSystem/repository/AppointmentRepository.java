package com.cg.HospitalManagmentSystem.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.cg.HospitalManagmentSystem.model.Appointment;
import com.cg.HospitalManagmentSystem.model.Nurse;
@CrossOrigin("*")
@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Integer>{
	
	
	@Query(
		value = "select * from appointment where physician = :phyId;",
		nativeQuery = true
	)
	public List<Appointment> findByPhysician(@Param("phyId") int phyId);
	
	
	@Query(
			value = "SELECT * FROM appointment WHERE physician = :phyId AND (starto >= :date and endo <= :date);",
			nativeQuery = true
			)
	public List<Appointment> findByPhysicianAndDate(@Param("phyId") int phyId, @Param("date") LocalDateTime date);
	@Query(
			value = "SELECT * FROM appointment WHERE physician = :phyId AND starto = :date;",
			nativeQuery = true
			)
	public List<Appointment> findByPhysicianAndDateThameem(@Param("phyId") int phyId, @Param("date") LocalDateTime date);
	
	

	public List<Appointment> findByStart(LocalDateTime startDate);
	
	
//	@Query("SELECT a.examinationRoom FROM Appointment a " +
//	           "JOIN Room r ON a.examinationRoom = r.roomNumber " +
//	           "WHERE a.physician.employeeID = :physicianId AND " +
//	           "a.starto <= :date AND a.endo >= :date")
//	    List<Room> findRoomDetailsByPhysicianIdAndDate(@Param("physicianId") int physicianId, @Param("date") LocalDateTime date);
	
	@Query("SELECT a FROM Appointment a WHERE a.patient.ssn = :patientId AND a.start <= :date AND a.end >= :date")

	List<Appointment> findByPatientIdAndDate(@Param("patientId") String patientId, @Param("date") LocalDateTime date);
	
	

    @Query("SELECT DISTINCT a.prepNurse FROM Appointment a WHERE a.patient.ssn = :patientId AND a.start <= :date AND a.end >= :date")
    
     List<Nurse> findNursesByPatientIdAndDate(@Param("patientId") String patientId, @Param("date") LocalDateTime date);
		  
		  

	 List<Appointment> findByPatientSsn(int patientId);
		  

	 Optional<Appointment> findByPatientSsnAndStartBetween(int patientId, LocalDateTime startOfDay, LocalDateTime endOfDay);


	 Optional<Appointment> findByPatientSsnAndStart(int patientId, LocalDateTime dateTime);
	 

     @Query("SELECT a.prepNurse FROM Appointment a WHERE a.patient.id = :patientId")

	 List<Nurse> findNursesByPatientId(@Param("patientId") int patientId);
    
    
    
	 @Query("SELECT a.examinationRoom FROM Appointment a WHERE appointmentID=?1")

	 public String getExaminationRoomBYappID(int id);


	  @Query(value="select *from appointment where prep_nurse =:nurseId",nativeQuery = true)

	  List<Appointment> findByPrepNurse(@Param("nurseId") Integer nurseid);
		 
		 
      @Query(value = "SELECT * FROM Appointment WHERE prep_nurse = ?1 AND Starto = ?2",

					nativeQuery = true)

	  public List<Appointment>  getPatientsByNurseAndDate(int nurseId, LocalDateTime startDate);
      @Query(value="SELECT * FROM Nurse  WHERE employeeID = (SELECT prepNurse FROM Appointment  WHERE appointmentID = :appointmentID)"

 			 , nativeQuery = true)

      public Nurse  getNurseByappId(@Param("appointmentID") Integer appointmentID );
	 
}
