package com.cg.HospitalManagmentSystem.exception;

public class PositionNotFoundException extends RuntimeException{
 
	public PositionNotFoundException(String msg)
	{
		super(msg);
	}
	
}
