package com.cg.HospitalManagmentSystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.HospitalManagmentSystem.model.Users;
import com.cg.HospitalManagmentSystem.serviceImpl.HMSUserServiceImpl;
@RestController

public class HMSUserController {
	@Autowired
	private HMSUserServiceImpl service;
	@PostMapping("/register")
	public Users register(@RequestBody Users user) {
		return service.register(user);
	}
	@PostMapping("/login")
	public String login(@RequestBody Users users) {
		return service.verify(users);
	}
}
