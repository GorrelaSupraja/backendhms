package com.cg.HospitalManagmentSystem.exception;

public class DepartmentsNotFoundException extends RuntimeException{
	public DepartmentsNotFoundException(String msg)
	{
		super(msg);
	}

}
