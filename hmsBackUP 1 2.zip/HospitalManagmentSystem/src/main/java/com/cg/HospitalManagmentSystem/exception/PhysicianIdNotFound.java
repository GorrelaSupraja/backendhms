package com.cg.HospitalManagmentSystem.exception;


public class PhysicianIdNotFound extends RuntimeException {
	public PhysicianIdNotFound(String msg) {
		super(msg);
	}
}
