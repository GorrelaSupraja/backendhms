package com.cg.HospitalManagmentSystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.cg.HospitalManagmentSystem.model.Undergoes;
import com.cg.HospitalManagmentSystem.model.UndergoesId;
@CrossOrigin("*")
@Repository
public interface UndergoesRepository extends JpaRepository<Undergoes, UndergoesId> {
	
}
