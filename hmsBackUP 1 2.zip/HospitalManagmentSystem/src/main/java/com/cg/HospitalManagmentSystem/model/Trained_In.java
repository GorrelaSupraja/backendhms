package com.cg.HospitalManagmentSystem.model;
 
import java.time.LocalDateTime;
 
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
 
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
 
@Entity
@Table(name = "Trained_In")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Trained_In {
 
    @EmbeddedId
    private TrainedInId id;
 
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Physician", referencedColumnName = "EmployeeID", insertable = false, updatable = false)
    @JsonIgnore
    private Physician physician;
 
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Treatment", referencedColumnName = "Code", insertable = false, updatable = false)
    @JsonIgnore
    private Procedures treatment;
 
    @Column(name = "CertificationDate", nullable = false)
    private LocalDateTime certificationDate;
 
    @Column(name = "CertificationExpires", nullable = false)
    private LocalDateTime certificationExpires;
 
    // Default Constructor
    public Trained_In() {
    }
 
    // Parameterized Constructor
    public Trained_In(TrainedInId id, Physician physician, Procedures treatment, LocalDateTime certificationDate, LocalDateTime certificationExpires) {
        this.id = id;
        this.physician = physician;
        this.treatment = treatment;
        this.certificationDate = certificationDate;
        this.certificationExpires = certificationExpires;
    }
 
    // Getters and Setters
    public TrainedInId getId() {
        return id;
    }
 
    public void setId(TrainedInId id) {
        this.id = id;
    }
 
    public Physician getPhysician() {
        return physician;
    }
 
    public void setPhysician(Physician physician) {
        this.physician = physician;
    }
 
    public Procedures getTreatment() {
        return treatment;
    }
 
    public void setTreatment(Procedures treatment) {
        this.treatment = treatment;
    }
 
    public LocalDateTime getCertificationDate() {
        return certificationDate;
    }
 
    public void setCertificationDate(LocalDateTime certificationDate) {
        this.certificationDate = certificationDate;
    }
 
    public LocalDateTime getCertificationExpires() {
        return certificationExpires;
    }
 
    public void setCertificationExpires(LocalDateTime certificationExpires) {
        this.certificationExpires = certificationExpires;
    }
 
    // toString Method
    @Override
    public String toString() {
        return "Trained_In [id=" + id + ", certificationDate=" + certificationDate + ", certificationExpires="
                + certificationExpires + "]";
    }
}