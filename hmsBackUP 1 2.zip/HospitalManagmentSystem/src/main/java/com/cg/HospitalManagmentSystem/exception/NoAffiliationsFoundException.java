package com.cg.HospitalManagmentSystem.exception;

public class NoAffiliationsFoundException extends RuntimeException
{
	public NoAffiliationsFoundException(String msg)
	{
		super(msg);
	}
}
