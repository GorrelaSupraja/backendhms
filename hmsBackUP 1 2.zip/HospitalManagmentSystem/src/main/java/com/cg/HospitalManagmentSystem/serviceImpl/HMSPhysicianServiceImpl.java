package com.cg.HospitalManagmentSystem.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.HospitalManagmentSystem.exception.PhysicianIdNotFound;
import com.cg.HospitalManagmentSystem.model.Physician;
import com.cg.HospitalManagmentSystem.repository.PhysicianRepository;
import com.cg.HospitalManagmentSystem.service.HMSPhysicianService;


@Service
public class HMSPhysicianServiceImpl implements HMSPhysicianService{
	
	@Autowired PhysicianRepository phyRepo;
	
	@Override
	public Physician getPhyById(int empid) {
		Physician p = phyRepo.findById(empid).orElse(null);
		if (p == null) throw new PhysicianIdNotFound(empid + " Not Found!");
		return p;
	}
	
	@Override
	public Physician getPhyByName(String name) {
		return phyRepo.findByName(name);
	}
	
	@Override
	public List<Physician> getPhyByPos(String pos) {
		return phyRepo.findByPosition(pos);
	}

	@Override
	public void addPhysician(Physician p) {
		phyRepo.save(p);
	}
	
	@Override
	public Physician updatePosition(String position, Integer employeeId) {
		Physician p = phyRepo.findById(employeeId).get();
		p.setPosition(position);
		phyRepo.save(p);
		return p;
	}

	@Override
	public Physician updateName(Integer empid, String newName) {
		Physician p = phyRepo.findById(empid).get();
		p.setName(newName);
		return phyRepo.save(p);
	}

	@Override
	public Physician updateSSN(Integer empid, Integer newSSN) {
		Physician p = phyRepo.findById(empid).get();
		p.setSsn(newSSN);
		return phyRepo.save(p);
	}
	
	public List<Physician> getAll() {
		return phyRepo.findAll();
	}
	
	public void savePhysician(Physician physician) {
		phyRepo.save(physician);
	}

}
