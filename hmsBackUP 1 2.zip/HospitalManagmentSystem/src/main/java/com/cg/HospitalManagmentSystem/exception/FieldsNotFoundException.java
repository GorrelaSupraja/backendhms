package com.cg.HospitalManagmentSystem.exception;

public class FieldsNotFoundException extends  RuntimeException{

	public FieldsNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
