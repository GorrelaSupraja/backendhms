package com.cg.HospitalManagmentSystem.exception;

public class AffiliatedWithExistsException extends RuntimeException 
{
	public AffiliatedWithExistsException(String msg)
	{
		super(msg);
	}
}
