package com.cg.HospitalManagmentSystem.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table (name = "Medication")
public class Medication {
    @Id
    @Column(name = "Code")
    private Integer code;

    @Column(nullable = false, length = 30, name = "Name")
    private String name;

    @Column(nullable = false, length = 30, name = "Brand")
    private String brand;

    @Column(nullable = false, length = 30, name = "Description")
    private String description;
    
    @OneToMany(mappedBy = "medication", cascade = CascadeType.ALL)
    private List<Prescribes> prescriptions;

	@Override
	public String toString() {
		return "Medication [code=" + code + ", name=" + name + ", brand=" + brand + ", description=" + description
				+ "]";
	}
    
    
}
