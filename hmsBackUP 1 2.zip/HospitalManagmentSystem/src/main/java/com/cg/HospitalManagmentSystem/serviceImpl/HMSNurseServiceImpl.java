package com.cg.HospitalManagmentSystem.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.HospitalManagmentSystem.exception.AlreadyFoundException;
import com.cg.HospitalManagmentSystem.exception.NurseNotFoundException;
import com.cg.HospitalManagmentSystem.exception.PositionNotFoundException;
import com.cg.HospitalManagmentSystem.model.Nurse;
import com.cg.HospitalManagmentSystem.repository.NurseRepository;
import com.cg.HospitalManagmentSystem.service.HMSNurseService;

@Service
public class HMSNurseServiceImpl implements HMSNurseService{
@Autowired
  private NurseRepository nurserepo;
 
@Override
public List<Nurse> getAll(){
	return  nurserepo.findAll();
	}

@Override
public Nurse getById(int empid) {
	
	Optional<Nurse> pro=nurserepo.findById(empid);
	if(pro.isEmpty())
	{
		throw new NurseNotFoundException("No nurse found for this id: "+ empid );
	}
	return pro.get();
}

@Override
public String getPosById(int empid) {
	String pos=nurserepo.findPosById(empid);
	if(pos==null) {
		throw new PositionNotFoundException(" No Position found for this id:"+empid);
	}
	
	return nurserepo.findPosById(empid);
}

@Override
public boolean findRegister(int empid) {
	return nurserepo.aboutRegister(empid);
}	

@Override
public Nurse saveNurse(Nurse nurse) {
   
	 int id =nurse.getEmployeeID() ;
	 if(nurserepo.existsById(id)) {
	 	throw new AlreadyFoundException("Nurse already  found By this Id");
	 }
	
	return nurserepo.save(nurse);
}


@Override
public Nurse updateNurseRegistrationStatus(int empid, Nurse n) {
    Optional<Nurse> nurseOptional = nurserepo.findById(empid);
    if (nurseOptional.isPresent()) {
        Nurse nurse = nurseOptional.get();
        nurse.setRegistered(n.getRegistered());
          return nurserepo.save(nurse);
      }
    return null;
}

@Override
public Nurse updateSSN(int empid,Nurse n) {
    Optional<Nurse> nurseOptional = nurserepo.findById(empid);
     
    
    if (nurseOptional.isPresent()) {
        Nurse nurse = nurseOptional.get();
        nurse.setSsn(n.getSsn());
        return nurserepo.save(nurse);
        }
	   return null;
}
}
