package com.cg.HospitalManagmentSystem.service;

import java.util.List;

import com.cg.HospitalManagmentSystem.model.Affiliated_With;
import com.cg.HospitalManagmentSystem.model.Department;
import com.cg.HospitalManagmentSystem.model.Physician;

public interface HMSAffiliatedWithService {
	
	public Affiliated_With createAffiliatedWith(Affiliated_With affObj);
	
	public List<Physician> getPhysiciansByDeptId(Integer deptid);
	
	public List<Department> getDepartmentsByPhyId(Integer phyId);
	
	public Integer findPhyCountByDeptId(Integer deptId);
	
	public boolean findPrimaryAffByPhyId(Integer physicianId);
	
	public List<Affiliated_With> getall();
	
	
	

}
