package com.cg.HospitalManagmentSystem.model;
 
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
 
@Entity
@Table(name = "Procedures")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Procedures {
 
    @Id
    private Integer code;
 
    @Column(nullable = false, length = 30)
    private String name;
 
    @Column(nullable = false)
    private Double cost;
 
    @OneToMany(mappedBy = "procedures")
    @JsonIgnore
    private List<Undergoes> undergoes;
 
    @OneToMany(mappedBy = "treatment")
    @JsonIgnore
    private List<Trained_In> trainedIns;
 
    // No-argument constructor
    public Procedures() {
    }
 
    // All-arguments constructor
    public Procedures(Integer code, String name, Double cost, List<Undergoes> undergoes, List<Trained_In> trainedIns) {
        this.code = code;
        this.name = name;
        this.cost = cost;
        this.undergoes = undergoes;
        this.trainedIns = trainedIns;
    }
 
    // Getters and Setters
    public Integer getCode() {
        return code;
    }
 
    public void setCode(Integer code) {
        this.code = code;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
 
    public Double getCost() {
        return cost;
    }
 
    public void setCost(Double cost) {
        this.cost = cost;
    }
 
    public List<Undergoes> getUndergoes() {
        return undergoes;
    }
 
    public void setUndergoes(List<Undergoes> undergoes) {
        this.undergoes = undergoes;
    }
 
    public List<Trained_In> getTrainedIns() {
        return trainedIns;
    }
 
    public void setTrainedIns(List<Trained_In> trainedIns) {
        this.trainedIns = trainedIns;
    }
 
    // toString method
    @Override
    public String toString() {
        return "Procedures [code=" + code + ", name=" + name + ", cost=" + cost + "]";
    }
}