package com.cg.HospitalManagmentSystem.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;

@Entity
@Table(name = "affiliated_with")
public class Affiliated_With {

    @EmbeddedId
    private AffiliatedWithId id;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @MapsId("physician")
    @JoinColumn(name = "Physician", referencedColumnName = "employeeID")
    private Physician physician;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @MapsId("department")
    @JoinColumn(name = "Department", referencedColumnName = "departmentID")
    private Department department;

    @Column(nullable = false, name = "PrimaryAffiliation")
    private Boolean primaryAffiliation;

	public AffiliatedWithId getId() {
		return id;
	}

	public void setId(AffiliatedWithId id) {
		this.id = id;
	}

	public Physician getPhysician() {
		return physician;
	}

	public void setPhysician(Physician physician) {
		this.physician = physician;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public Boolean getPrimaryAffiliation() {
		return primaryAffiliation;
	}

	public void setPrimaryAffiliation(Boolean primaryAffiliation) {
		this.primaryAffiliation = primaryAffiliation;
	}

	public Affiliated_With(AffiliatedWithId id, Physician physician, Department department, Boolean primaryAffiliation) {
		this.id = id;
		this.physician = physician;
		this.department = department;
		this.primaryAffiliation = primaryAffiliation;
	}

    public Affiliated_With() {}

	@Override
	public String toString() {
		return "Affiliated_With [id=" + id + ", primaryAffiliation=" + primaryAffiliation + "]";
	}
    
    
}

