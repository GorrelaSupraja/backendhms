package com.cg.HospitalManagmentSystem.controller;


import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.HospitalManagmentSystem.model.Patient;
import com.cg.HospitalManagmentSystem.model.Physician;
import com.cg.HospitalManagmentSystem.repository.PhysicianRepository;
import com.cg.HospitalManagmentSystem.service.HMSPatientService;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
@Transactional
public class HMSPatientController {
	
	  private HMSPatientService patientService;
	
	  private  PhysicianRepository physicianRepository;  

	  @GetMapping("api/patient")
	  public ResponseEntity<List<Patient>> getAllPatients() {
		 
	    List<Patient> li=patientService.getAllPatients();
	        return new ResponseEntity<List<Patient>>(li, HttpStatus.OK);
	  }
	 
	 
	 @GetMapping("api/patient/{physicianid}")
	   public ResponseEntity<List<Patient>> getPatientsByPhysicianId(@PathVariable("physicianid") int physicianId) {
		 
	     List<Patient> patients = patientService.getPatientsByPhysicianId(physicianId);
	        if (patients.isEmpty()) {
	            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	       }
	      return new ResponseEntity<>(patients, HttpStatus.OK);
	   }
	 @GetMapping("api/patient/{physicianid}/{patientid}")
	   public ResponseEntity<Patient> getPatientByPhysicianIdAndPatientId( @PathVariable("physicianid") int physicianId,@PathVariable("patientid") int patientId) {
		 
	      Patient patient = patientService.getPatientByPhysicianIdAndPatientId(physicianId, patientId);
	      if (patient != null) {
	          return new ResponseEntity<>(patient, HttpStatus.OK);
	       } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }

	  
	    @GetMapping("api/patient/insurance/{patientid}")
	    public ResponseEntity<Integer> getPatientInsuranceByPatientId(@PathVariable("patientid") int patientId) {
	    	
	        Integer insuranceId = patientService.getPatientInsuranceByPatientId(patientId);
	        return new ResponseEntity<>(insuranceId, HttpStatus.OK);
	    }
	    
	    @GetMapping("api/appointment/physician/{patientid}")
	    public ResponseEntity<List<Physician>> getPhysiciansByPatientId(@PathVariable("patientid") int patientId) {
	        
	            List<Physician> physicians = patientService.getPhysiciansByPatientId(patientId);
	            return new ResponseEntity<>(physicians, HttpStatus.OK);
	        
	    }
	    
	    @PostMapping("api/patient")
	    public ResponseEntity<String> addPatient(@RequestBody Patient patient) {
	        try {
	            // Fetch the physician by ID to set the correct reference
	            Physician pcp = patient.getPcp();
	            if (pcp != null && pcp.getEmployeeID() != null) {
	                pcp = physicianRepository.findById(pcp.getEmployeeID())
	                        .orElseThrow(() -> new RuntimeException("Physician not found"));
	                patient.setPcp(pcp);
	            }

	            patientService.addPatient(patient);
	            return ResponseEntity.status(HttpStatus.CREATED).body("Record Created Successfully");
	        } catch (Exception e) {
	            e.printStackTrace();
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
	        }
	    }
	    
	    @PutMapping("api/patient/address/{address}/{ssn}")
	    public ResponseEntity<String> updateAddress(@PathVariable("ssn") int ssn, @PathVariable("address") String address) {
        boolean isUpdated = patientService.updateAddress(ssn, address);
        if (isUpdated) {
            return ResponseEntity.ok("Address updated successfully");
        } else {
            return ResponseEntity.notFound().build();
        }
    }
	    
	    @PutMapping("api/patient/phone/{phone}/{ssn}")
	    public ResponseEntity<String> updatePhone(@PathVariable("ssn") Integer ssn, @PathVariable("phone") String phone) {
	        String response = patientService.updatePhone(ssn, phone);
	        return ResponseEntity.ok(response);
	    }
}
