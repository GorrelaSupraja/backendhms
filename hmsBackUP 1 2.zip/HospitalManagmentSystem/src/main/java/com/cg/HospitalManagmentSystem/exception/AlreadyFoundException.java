package com.cg.HospitalManagmentSystem.exception;

public class AlreadyFoundException  extends RuntimeException{

	public  AlreadyFoundException(String msg)
	{
		super(msg);
	}
}
