package com.cg.HospitalManagmentSystem.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.HospitalManagmentSystem.model.Affiliated_With;
import com.cg.HospitalManagmentSystem.model.Department;
import com.cg.HospitalManagmentSystem.model.Physician;
import com.cg.HospitalManagmentSystem.serviceImpl.HMSAffiliatedWithServiceImpl;

import jakarta.transaction.Transactional;
//@CrossOrigin(origins = "http://localhost:4200")
@RestController
@Transactional
public class HMSAffiliatedWithController {
	
	@Autowired
	private HMSAffiliatedWithServiceImpl affService;
	
	@PostMapping("/api/affiliated_with/post")
	public ResponseEntity<String> createAffilatedWith(@RequestBody Affiliated_With aff)
	{
		affService.createAffiliatedWith(aff);
		return new ResponseEntity<String>("Record Created Successfully", HttpStatus.CREATED);
	}
	
	//Searching for list of physician affiliated with particular department
	@GetMapping("/api/affiliated_with/physicians/{deptid}")
	public ResponseEntity<List<Physician>> getPhysiciansByDeptId(@PathVariable("deptid") Integer departmentId){
		List<Physician> phylist=affService.getPhysiciansByDeptId(departmentId);
		return new ResponseEntity<List<Physician>>(phylist, HttpStatus.OK);
		
	}
	
	//Searching for list of department for a physician
	@GetMapping("/api/affiliated_with/department/{physicianid}")
	public ResponseEntity<List<Department>> getDepartmenstByPhyId(@PathVariable("physicianid") Integer physicianId)
	{
		List<Department> dept=affService.getDepartmentsByPhyId(physicianId);
		return new ResponseEntity<List<Department>>(dept, HttpStatus.OK);
	}
	
	//Count total number of physician in a department
	@GetMapping("/api/affiliated_with/countphysician/{deptid}")
	public ResponseEntity<Integer> findPhyCountByDeptId(@PathVariable("deptid") Integer departmentId)
	{
		Integer i1=affService.findPhyCountByDeptId(departmentId);
		return new ResponseEntity<Integer>(i1, HttpStatus.OK);
	}
	
	//Search the primary affiliation of physician
	@GetMapping("/api/affiliated_with/primary/{physicianid}/")
	public boolean findPrimaryAffByPhyId(@PathVariable("physicianid") Integer physicianId)
	{
		return affService.findPrimaryAffByPhyId(physicianId);
	}

	@GetMapping("/api/getaffiliatedAll")
	public List<Affiliated_With> getall()
	{
		return affService.getall();
	}
	
	
	
}

