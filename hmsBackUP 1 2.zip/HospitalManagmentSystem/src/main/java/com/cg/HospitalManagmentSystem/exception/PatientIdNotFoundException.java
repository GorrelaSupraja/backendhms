package com.cg.HospitalManagmentSystem.exception;

public class PatientIdNotFoundException  extends RuntimeException{
	
	public PatientIdNotFoundException(String msg) {
		super(msg);
	}

}
