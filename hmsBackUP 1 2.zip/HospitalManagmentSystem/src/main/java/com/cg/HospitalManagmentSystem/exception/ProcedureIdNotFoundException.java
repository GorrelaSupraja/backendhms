package com.cg.HospitalManagmentSystem.exception;

public class ProcedureIdNotFoundException extends RuntimeException
{

	public ProcedureIdNotFoundException(String msg)
	{
		super(msg);
	}
	
}
