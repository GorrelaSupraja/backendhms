package com.cg.HospitalManagmentSystem;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import com.cg.HospitalManagmentSystem.model.Nurse;
import com.cg.HospitalManagmentSystem.repository.NurseRepository;

import jakarta.transaction.Transactional;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Transactional
public class HMSNurseServicTest {
	@Autowired
    private TestRestTemplate restTemplate;
	
	@Autowired
    private NurseRepository nurseRepo;
 
    private Nurse n;
 
    @BeforeEach
    public void setup() {
        n = nurseRepo.findById(101).orElse(null);
    }
    
    @Test
    public void testGetAllNurse() {
       String url = "/api/nurse/";
       ResponseEntity<Nurse[]> response = restTemplate.getForEntity(url, Nurse[].class);

       assertEquals(HttpStatus.OK, response.getStatusCode());
       assertNotNull(response.getBody());
       assertTrue(response.getBody().length > 0);
}
	
    @Test
    public void testGetNurseById() {
        String url = "/api/nurse/" + n.getEmployeeID();
        ResponseEntity<Nurse> response = restTemplate.getForEntity(url, Nurse.class);
 
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(n.getName(), response.getBody().getName());
    }
    
    @Test
    public void testGetNursePosition() {
     String url = "/api/nurse/position/"+ n.getEmployeeID();
 ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
       assertTrue(response.getBody().length() > 0);
         }
    
    @Test
    public void testIsNurseRegistered() {
        String url = "/api/nurse/registered/"+n.getEmployeeID();
        
        ResponseEntity<Boolean> response = restTemplate.getForEntity(url, Boolean.class);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(true, response.getBody());
    }
    

    @Test
    public void testPostNurse() {
        String url = "/api/nurse";

       
        String post = """
        			{ 
               "employeeID": 108,
                "name": "Jane",
                "position": "Head",
                "ssn": 1000234,
                "registered": true
                }""" ;

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> request = new HttpEntity<>(post, headers);
        ResponseEntity<String> response = restTemplate.postForEntity(url, request,String.class);
         assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Record Created Successfully", response.getBody());
    }
    	

    @Test
    public void testUpdateNurseSsn() throws Exception {
        String url = "/api/nurse/ssn/101";

       
        String json =  """
        		{
                 "ssn": 34526727 
                }""";
               
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> request = new HttpEntity<>(json, headers);

        ResponseEntity<Nurse> response = restTemplate.exchange(url, HttpMethod.PUT, request, Nurse.class);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(34526727, response.getBody().getSsn());
    }
    @Test
    public void testUpdateNurseRegistrationStatus() throws Exception {
       
        String url="/api/nurse/registered/102";
        
        String status =  """
        		{
        		 "registered": true
        	  }""";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> request = new HttpEntity<>(status, headers);
        
        ResponseEntity<Nurse> response = restTemplate.exchange(url, HttpMethod.PUT, request, Nurse.class);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(true, response.getBody().getRegistered());
    }
    

 
}