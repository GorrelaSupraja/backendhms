package com.cg.HospitalManagmentSystem;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.cg.HospitalManagmentSystem.model.Department;
import com.cg.HospitalManagmentSystem.model.Physician;
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class HMSAffiliatedWithTest 

{
	@Autowired
	private TestRestTemplate restTemplate;
	
	 	@Test
	    public void testFindPhyCountByDeptId() {
	        Integer deptId = 1; 

	        ResponseEntity<Integer> response = restTemplate.getForEntity("/api/affiliated_with/countphysician/{deptid}", Integer.class, deptId);

	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertNotNull(response.getBody());
	        assertTrue(response.getBody() >=0);
	    }
	 	
	 	@Test
	    public void testFindPrimaryAffByPhyId() {
	        Integer phyId = 2; 
	        ResponseEntity<Boolean> response = restTemplate.getForEntity("/api/affiliated_with/primary/{physicianid}/", Boolean.class, phyId);

	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertNotNull(response.getBody());
	        System.out.println(response.getBody());
	        assertTrue(response.getBody());
	    }
	 	@Test
	    public void testGetDepartmentsByPhyId() {
	        Integer phyId = 1;

	        ResponseEntity<List> response = restTemplate.getForEntity("/api/affiliated_with/department/{physicianid}", List.class, phyId);

	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertNotNull(response.getBody());
	        assertTrue(response.getBody().size() > 0);
	    }
	 	
	 	
	 	

		
}
