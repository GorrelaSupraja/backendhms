package com.cg.HospitalManagmentSystem;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;

import jakarta.transaction.Transactional;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Transactional
public class HMSPatientServiceTest {
	
	
	    @Autowired
	    private TestRestTemplate restTemplate;
//	    @Test
//	    public void testGetAllPatients() {
//	        String url = "/api/patient";
//
//	        // Execute GET request and expect a JSON array response as a string
//	        ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
//
//	        // Assert that the response status code is 200 OK
//	        assertEquals(HttpStatus.OK, response.getStatusCode());
//
//	        // Parse the JSON response body into an array of Patient objects
//	        ObjectMapper mapper = new ObjectMapper();
//	        try {
//	            Patient[] patientsArray = mapper.readValue(response.getBody(), Patient[].class);
//	            
//	            // Convert the array into a List for easier assertions
//	            List<Patient> patientsList = Arrays.asList(patientsArray);
//
//	            // Assert that the list is not null and contains elements
//	            assertNotNull(patientsList);
//	            assertFalse(patientsList.isEmpty(), "The patients list should not be empty");
//
//	        } catch (JsonProcessingException e) {
//	            // Fail the test if JSON processing fails
//	            fail("Failed to parse JSON response: " + e.getMessage());
//	        }
//	    }



//	@Test
//	public void testAddPatient() {
//	    Patient newPatient = new Patient();
//	    newPatient.setSsn(123456789);
//	    newPatient.setName("John Doe");
//	    newPatient.setAddress("123 Main St");
//	    newPatient.setPhone("555-1234");
//	    newPatient.setInsuranceID(456);
//
//	    HttpEntity<Patient> request = new HttpEntity<>(newPatient);
//	    ResponseEntity<String> response = restTemplate.postForEntity("/api/patient", request, String.class);
//
//	    assertEquals(HttpStatus.CREATED, response.getStatusCode());
//	    assertEquals("Record Created Successfully", response.getBody());
//	} 
	   @Test
	   public void testUpdatePatientAddress() {
	       int ssn = 100000001; // Assume this SSN exists
	       String newAddress = "456 Elm St";
	       String url = UriComponentsBuilder.fromPath("/api/patient/address/{ssn}")
	                                        .queryParam("address", newAddress)
	                                        .buildAndExpand(ssn)
	                                        .toUriString();

	       HttpEntity<Void> request = new HttpEntity<>(null);
	       ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.PUT, request, String.class);

	       assertEquals(HttpStatus.OK, response.getStatusCode());
	       assertEquals("Address updated successfully", response.getBody());
	   }
	   
	   @Test
	   public void testUpdatePatientPhone() {
	       // Assuming there's a patient with SSN 123456789 already in the database
	       int ssn = 5678;
	       String newPhone = "555-5678";
	       
	       String url = "/api/patient/phone/" + ssn + "?phone=" + newPhone;
	       ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.PUT, null, String.class);
	       
	       assertEquals(HttpStatus.OK, response.getStatusCode());
	       assertEquals("Phone updated successfully", response.getBody());
	   }
	   
	   
//	   @Test
//	   public void testGetPhysicianByPatientIdAndDate() {
//	       String patientId = "123";
//	       String date = "2023-09-01 10:00:00"; // Ensure this date format matches your expectations
//
//	       // Build the request URL
//	       String url = UriComponentsBuilder.fromPath("/api/appointment/physician/{patientId}/{date}")
//	                                        .buildAndExpand(patientId, date)
//	                                        .toUriString();
//
//	       // Execute the GET request
//	       ResponseEntity<Physician[]> response = restTemplate.getForEntity(url, Physician[].class);
//
//	       // Assert the response status code
//	       assertEquals(HttpStatus.OK, response.getStatusCode());
//
//	       // Assert that the response body is not null and contains physicians
//	       Physician[] physicians = response.getBody();
//	       assertNotNull(physicians);
//	       assertTrue(physicians.length > 0);
//	   }
//	   @Test
//	    public void testGetPatientByPhysicianIdAndPatientId() {
//	        // Arrange
//	        int physicianId = 1;
//	        int patientId = 100000001;
//	        String url = "/api/patient/" + physicianId + "/" + patientId;
//
//	        // Act
//	        ResponseEntity<Patient> response = restTemplate.getForEntity(url, Patient.class);
//	        assertEquals(HttpStatus.OK, response.getStatusCode());
//	   	}
	  
	   



}
