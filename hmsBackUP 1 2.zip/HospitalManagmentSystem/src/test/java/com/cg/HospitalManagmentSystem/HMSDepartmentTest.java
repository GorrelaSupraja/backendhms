package com.cg.HospitalManagmentSystem;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;



import org.json.JSONException;

import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;



@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class HMSDepartmentTest 
{
	@Autowired
	private TestRestTemplate restTemplate;
	
	private static String url="/api/departments/";
	
	String strDepartments="""
						[
							{
								"departmentID": 1 
							},
							{
								"departmentID": 2
							},
							{
								"departmentID": 3
							},
							{
								"departmentID": 11
							}
							
						]
					""";
	@Test
	public void testGetAllDepartments() throws JSONException {
		ResponseEntity<String> resp=restTemplate.getForEntity(url, String.class);
		System.out.println("Expected JSON: " + strDepartments);
	    System.out.println("Actual JSON: " + resp.getBody());
		JSONAssert.assertEquals(strDepartments, resp.getBody(), false);
		
	}
	
	@Test
    public void testDepartmentExistsByPhysicianId() {
        Integer physicianId = 7; 
        ResponseEntity<Boolean> response = restTemplate.getForEntity("/api/department/check/{physicianid}", Boolean.class, physicianId);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody());
    }
	
			private static String getheadByDeptId="/api/department/head/1";
	
			String strhead="""
					{
						
						"employeeID": 4,
                        "name": "Percival Cox",
						"position": "Senior Attending Physician",
						"ssn": 444444444
					}
						""";
			@Test
			public void TestgetHeadByDeptId() throws JSONException {
				ResponseEntity<String> resp=restTemplate.getForEntity(getheadByDeptId, String.class);
				JSONAssert.assertEquals(strhead, resp.getBody(), true);
			}
			//failed on purpose
			@Test
			public void testAddDepartment() throws JSONException {
			    String url = "/api/department";
			    String JSONbody = """
			    {
			        "departmentID": 11,
			        "name": "General Medicine",
			        "head": {
			            "employeeID": 4,
			            "name": "Percival Cox",
			            "position": "Senior Attending Physician",
			            "ssn": 444444444
			        }
			    }`	
			    """;

			    HttpHeaders headers = new HttpHeaders();
			    headers.setContentType(MediaType.APPLICATION_JSON);
			    HttpEntity<String> request = new HttpEntity<>(JSONbody, headers);

			    ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, request, String.class);

			    assertEquals(HttpStatus.CREATED, response.getStatusCode());
			}
			
			
			
			@Test
			public void testUpdateDeptName() throws JSONException {
			    String url = "/api/department/update/deptname/11";
			    String JSONbody = """
			    {
			    		 
			    		 "name": "Mahesh"
			    		 
			    }
			    """;
			    HttpHeaders headers = new HttpHeaders();
			    headers.setContentType(MediaType.APPLICATION_JSON);
			    HttpEntity<String> request = new HttpEntity<>(JSONbody, headers);
				ResponseEntity<String> response = restTemplate.exchange(url,HttpMethod.PUT, request, String.class);
				assertEquals(HttpStatus.OK, response.getStatusCode());
			}

			
	
}
