package com.cg.HospitalManagmentSystem;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.cg.HospitalManagmentSystem.model.Appointment;
import com.cg.HospitalManagmentSystem.model.Patient;
import com.cg.HospitalManagmentSystem.repository.AppointmentRepository;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class HMSAppointmentServiceTest {

    @Autowired
    private TestRestTemplate restTemplate;


    @Test
    public void testGetAppointmentDatesByPatientId() {
        // Arrange
        int patientId = 100000001; // example patient ID
        String url = "/api/appointment/date/" + patientId;

        // Act
        ResponseEntity<LocalDateTime[]> response = restTemplate.getForEntity(url, LocalDateTime[].class);

        // Assert
//        if (response.getStatusCode() == HttpStatus.OK) {
////            assertNotNull(response.getBody());
////            assertTrue(response.getBody().length > 0, "Appointment dates should not be empty");
//        	System.out.println(response.getStatusCode());
//        	assertEquals(HttpStatus.OK, response.getStatusCode());
//        }
//        else {
//            assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
//        }
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }
    @Test
    public void testGetExaminationRoomByPatientIdAndDate() {
        // Arrange
        int patientId = 100000001; // Example patient ID
        LocalDate date = LocalDate.of(2008, 4, 26); // Example date
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
        LocalDateTime startOfDay = date.atStartOfDay();
        LocalDateTime endOfDay = date.atTime(LocalTime.MAX);
        String formattedDate = startOfDay.format(formatter); // Using startOfDay for testing
        String url = "/api/appointment/room/patientId/" + patientId + "/date/" + formattedDate;

        // Act
        ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);

        // Assert
        if (response.getStatusCode() == HttpStatus.OK) {
            String room = response.getBody();
            assertNotNull(room, "Examination room should not be null");
            assertEquals("C", room, "Expected examination room for the given date and patient");
        } else if (response.getStatusCode() == HttpStatus.BAD_REQUEST) {
            String errorMessage = response.getBody();
            assertTrue(errorMessage.contains("Invalid date format"), "Error message should indicate invalid date format");
        } else if (response.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
            String errorMessage = response.getBody();
            assertTrue(errorMessage.contains("Error fetching data"), "Error message should indicate internal server error");
        }
    }

}
