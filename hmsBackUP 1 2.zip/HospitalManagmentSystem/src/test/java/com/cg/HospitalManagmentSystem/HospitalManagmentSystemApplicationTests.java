package com.cg.HospitalManagmentSystem;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.HospitalManagmentSystem.repository.PhysicianRepository;
import com.cg.HospitalManagmentSystem.service.HMSPhysicianService;

import jakarta.transaction.Transactional;

@SpringBootTest
class HospitalManagmentSystemApplicationTests {
	void contextLoads() {

	}

}
