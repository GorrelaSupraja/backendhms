package com.cg.HospitalManagmentSystem;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.json.JSONException;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.cg.HospitalManagmentSystem.model.Appointment;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class HMSAppointmentTest {

	@Autowired
	 private TestRestTemplate restTemplate;
	
	 @Test
	 public void testGetAllAppointments() 
	 {
	       String url = "/api/appointment";
	       ResponseEntity<Appointment[]> response = restTemplate.getForEntity(url, Appointment[].class);
	       assertEquals(HttpStatus.OK, response.getStatusCode());

	}
	 
	 @Test
	   public void getAppointmentByStartDate() throws JSONException
	   {
		   String url = "/api/appointment/2008-04-25T10:00:00";
	       String expected="""
	       		[
				{
			        "appointmentID": 36549879,
			        "patient": 100000001,
			        "prepNurse": 102,
			        "physician": 1,
			        "start": "2008-04-25T10:00:00",
			        "end": "2008-04-25T11:00:00",
			        "examinationRoom": "A"
			    },
			    {
			        "appointmentID": 46846589,
			        "patient": 100000004,
			        "prepNurse": 103,
			        "physician": 4,
			        "start": "2008-04-25T10:00:00",
			        "end": "2008-04-25T11:00:00",
			        "examinationRoom": "B"
	       		 }
				 ]
	       		""";
	       ResponseEntity<String> res=restTemplate.getForEntity(url, String.class);
	       JSONAssert.assertEquals(expected, res.getBody(), true);
	   }

}
